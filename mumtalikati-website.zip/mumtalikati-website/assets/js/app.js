(function(){
'use strict';
/* ---------- ICONS ---------- */
const I = (p, s=18, w=1.8) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
const ic = {
  arrow: s=>I('<path d="M5 12h14M13 6l6 6-6 6"/>',s),
  left: s=>I('<path d="M15 18l-6-6 6-6"/>',s),
  right: s=>I('<path d="M9 6l6 6-6 6"/>',s),
  heart: s=>I('<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>',s),
  heartF: s=>`<svg width="${s||18}" height="${s||18}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/></svg>`,
  bed: s=>I('<path d="M3 18v-6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6M3 14h18M7 10V7h4v3M3 18v2M21 18v2"/>',s||16),
  bath: s=>I('<path d="M4 12h16v3a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4v-3zM6 12V6a2 2 0 0 1 4 0M6 19l-1 2M18 19l1 2"/>',s||16),
  size: s=>I('<path d="M4 4h16v16H4zM4 9h5V4M20 15h-5v5"/>',s||16),
  pin: s=>I('<path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',s||16),
  search: s=>I('<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',s),
  spark: s=>I('<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>',s),
  check: s=>I('<path d="M5 12.5l4.5 4.5L19 7.5"/>',s||16,2.2),
  close: s=>I('<path d="M6 6l12 12M18 6L6 18"/>',s),
  menu: s=>I('<path d="M4 7h16M4 12h16M4 17h16"/>',s),
  plus: s=>I('<path d="M12 5v14M5 12h14"/>',s),
  send: s=>I('<path d="M5 12h13M13 6l6 6-6 6"/>',s||18,2.2),
  cheque: s=>I('<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 14h5M15 14h2M7 10h10"/>',s),
  doc: s=>I('<path d="M7 3h7l5 5v13H7zM14 3v5h5M10 13h6M10 17h6"/>',s),
  wrench: s=>I('<path d="M14.7 6.3a4 4 0 0 0 5 5L22 14l-8 8-2.3-2.3 0 0a4 4 0 0 0-5-5L2 10l4-4 2.3 2.3a4 4 0 0 0 6.4-2z"/>',s),
  users: s=>I('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M21.5 20a6.5 6.5 0 0 0-4-6"/>',s),
  globe: s=>I('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',s),
  chart: s=>I('<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',s),
  shield: s=>I('<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',s),
  chat: s=>I('<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>',s),
  cal: s=>I('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',s),
  key: s=>I('<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3M15 8l2 2"/>',s),
  phone: s=>I('<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',s),
  wa: s=>`<svg width="${s||18}" height="${s||18}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.1l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.2-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.6a2.7 2.7 0 0 0 1.8-1.2 2.2 2.2 0 0 0 .1-1.2c0-.1-.2-.2-.4-.3z"/></svg>`,
  flat: s=>I('<rect x="5" y="3" width="14" height="18" rx="1.5"/><path d="M9 7h2M13 7h2M9 11h2M13 11h2M9 15h2M13 15h2M11 21v-3h2v3"/>',s||28,1.6),
  villa: s=>I('<path d="M3 11l9-7 9 7M5 9.5V20h14V9.5M10 20v-5h4v5"/>',s||28,1.6),
  town: s=>I('<path d="M2 20V10l5-4 5 4v10M12 20V10l5-4 5 4v10M5 20v-4h4v4M15 20v-4h4v4M2 20h20"/>',s||28,1.6),
  shop: s=>I('<path d="M4 9l1.5-5h13L20 9M4 9v11h16V9M4 9c0 1.7 1.3 2.5 2.7 2.5S9.3 10.7 9.3 9c0 1.7 1.3 2.5 2.7 2.5s2.7-.8 2.7-2.5c0 1.7 1.3 2.5 2.7 2.5S20 10.7 20 9M10 20v-5h4v5"/>',s||28,1.6),
  office: s=>I('<path d="M4 21V5l8-2v18M12 7l8 2v12M7 8h2M7 12h2M7 16h2M15 12h2M15 16h2M2 21h20"/>',s||28,1.6),
  ware: s=>I('<path d="M2 21V9l10-5 10 5v12M6 21v-8h12v8M6 16h12"/>',s||28,1.6),
  bldg: s=>I('<path d="M3 21h18M5 21V4h9v17M14 9h5v12M8 8h3M8 12h3M8 16h3"/>',s||28,1.6),
  all: s=>I('<rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/>',s||28,1.6),
  map: s=>I('<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2zM9 4v14M15 6v14"/>',s),
  list: s=>I('<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',s),
  sun: s=>I('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',s),
  moon: s=>I('<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',s),
  bolt: s=>I('<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',s),
  eye: s=>I('<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',s),
  apple: s=>`<svg width="${s||20}" height="${s||20}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M16.4 12.6c0-2.6 2.1-3.8 2.2-3.9a4.8 4.8 0 0 0-3.8-2c-1.6-.2-3.1.9-3.9.9s-2-.9-3.4-.9a5 5 0 0 0-4.2 2.6c-1.8 3.1-.5 7.7 1.3 10.2.9 1.2 1.9 2.6 3.2 2.6s1.8-.8 3.3-.8 2 .8 3.3.8 2.2-1.3 3-2.5a10 10 0 0 0 1.4-2.8 4.3 4.3 0 0 1-2.4-4.2zM13.9 5a4.4 4.4 0 0 0 1-3.2 4.5 4.5 0 0 0-2.9 1.5 4.2 4.2 0 0 0-1 3.1A3.7 3.7 0 0 0 13.9 5z"/></svg>`,
  play: s=>`<svg width="${s||20}" height="${s||20}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M4 2.5v19l17-9.5z"/></svg>`
};
const logo = (s=40,id='lg') => `<svg width="${s}" height="${s}" viewBox="0 0 40 40" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#F7941D"/><stop offset="1" stop-color="#D7262E"/></linearGradient></defs><path d="M20 4 L35 16 V35 H5 V16 Z" fill="none" stroke="url(#${id})" stroke-width="3" stroke-linejoin="round"/><rect x="14" y="18" width="5.5" height="5.5" rx="1" fill="url(#${id})"/><rect x="20.5" y="18" width="5.5" height="5.5" rx="1" fill="url(#${id})"/><rect x="14" y="24.5" width="5.5" height="5.5" rx="1" fill="url(#${id})"/><rect x="20.5" y="24.5" width="5.5" height="5.5" rx="1" fill="url(#${id})"/></svg>`;

/* ---------- SCENES (illustrated property imagery) ---------- */
let uid = 0;
function rnd(seed){ let s = (seed*9301+49297)%233280; return ()=>{ s=(s*9301+49297)%233280; return s/233280; }; }
const SKY = { day:['#A9D3EA','#F3EEE7','#FFF6D8'], golden:['#F3A86B','#FBE2C8','#FFE2A8'], dusk:['#47406E','#E9977A','#FFC48A'], night:['#141A33','#3B2F52','#FFE9B0'] };
function palm(x,y,h,c){ return `<g transform="translate(${x},${y})"><path d="M0 0 C 3 ${-h*0.5} -2 ${-h*0.8} 2 ${-h}" stroke="${c||'#6B4A33'}" stroke-width="5" fill="none" stroke-linecap="round"/>
<g transform="translate(2,${-h})" fill="#3E7A4E"><path d="M0 0 C -18 -6 -32 2 -40 14 C -26 4 -14 2 0 0z"/><path d="M0 0 C 18 -8 32 -2 42 10 C 28 2 14 2 0 0z"/><path d="M0 0 C -8 -16 -2 -30 8 -36 C 2 -24 2 -12 0 0z"/><path d="M0 0 C -22 -18 -34 -14 -42 -6 C -28 -12 -14 -8 0 0z" fill="#4C8B5C"/><path d="M0 0 C 20 -20 34 -18 40 -10 C 28 -14 14 -8 0 0z" fill="#4C8B5C"/></g></g>`; }
function mountains(sky, op){ const c = sky==='night'?'#2B2742':sky==='dusk'?'#8B6676':'#C7A68E'; return `<path d="M0 205 L40 170 L75 188 L120 140 L160 176 L210 128 L255 168 L300 138 L345 172 L400 150 V300 H0Z" fill="${c}" opacity="${op||.55}"/><path d="M0 222 L60 196 L110 214 L170 182 L230 210 L290 186 L350 208 L400 194 V300 H0Z" fill="${c}" opacity="${(op||.55)*0.8}"/>`; }
function skyDefs(id,t){ const s=SKY[t]; return `<linearGradient id="sk${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${s[0]}"/><stop offset="1" stop-color="${s[1]}"/></linearGradient>`; }
function sun(t){ const s=SKY[t]; if(t==='night') return `<circle cx="320" cy="60" r="16" fill="${s[2]}" opacity=".9"/><g fill="#fff" opacity=".7"><circle cx="60" cy="40" r="1.2"/><circle cx="140" cy="70" r="1"/><circle cx="210" cy="30" r="1.3"/><circle cx="260" cy="90" r="1"/><circle cx="370" cy="110" r="1.1"/></g>`; return `<circle cx="${t==='day'?310:330}" cy="${t==='day'?62:150}" r="${t==='day'?24:30}" fill="${s[2]}" opacity="${t==='day'?.9:.95}"/>`; }
function windows(x,y,cols,rows,w,h,gx,gy,lit,r,arch){ let o=''; for(let i=0;i<rows;i++) for(let j=0;j<cols;j++){ const on = lit && r()<0.45; const cx=x+j*(w+gx), cy=y+i*(h+gy); o+= arch ? `<path d="M${cx} ${cy+h} V${cy+w/2} A${w/2} ${w/2} 0 0 1 ${cx+w} ${cy+w/2} V${cy+h}Z" fill="${on?'#FFD58C':'#8FB7CC'}" opacity="${on?1:.75}"/>` : `<rect x="${cx}" y="${cy}" width="${w}" height="${h}" rx="2" fill="${on?'#FFD58C':'#8FB7CC'}" opacity="${on?1:.75}"/>`; } return o; }
function scene(kind, seed, t){
  const id = 'sc'+(uid++); const r = rnd(seed); t = t||'day'; const lit = t==='dusk'||t==='night';
  let body='';
  const ground = t==='night'?'#3A2E33':t==='dusk'?'#B98B78':'#E7D6C3';
  if(kind==='tower'){
    const w=170+Math.floor(r()*40), x=110+Math.floor(r()*20), top=60+Math.floor(r()*30);
    body = mountains(t,.45)+`<rect x="${x+10}" y="${top+8}" width="${w}" height="${236-top}" fill="#000" opacity=".08"/>
    <rect x="${x}" y="${top}" width="${w}" height="${236-top}" fill="${t==='night'?'#CFC4BC':'#FBF7F1'}"/><rect x="${x+w-34}" y="${top}" width="34" height="${236-top}" fill="#000" opacity=".06"/>
    <rect x="${x-6}" y="${top-8}" width="${w+12}" height="10" rx="2" fill="${t==='night'?'#B8ACA4':'#EFE6DB'}"/>
    ${windows(x+16,top+18,Math.floor((w-30)/30),Math.floor((190-top)/32),18,22,12,10,lit,r,true)}
    <rect x="${x}" y="206" width="${w}" height="30" fill="#B4232A" opacity=".88"/><rect x="${x+12}" y="212" width="${w-24}" height="18" fill="#8FB7CC" opacity=".6"/>`+palm(70,250,90)+palm(332,252,70);
  } else if(kind==='villa'){
    body = mountains(t,.5)+`<rect x="40" y="198" width="320" height="44" fill="${t==='night'?'#BFAE9F':'#F1E6D7'}"/>
    <rect x="95" y="120" width="210" height="100" fill="${t==='night'?'#D8CCC2':'#FBF6EE'}"/><rect x="140" y="80" width="120" height="44" fill="${t==='night'?'#D0C3B8':'#F7F0E6'}"/>
    ${[0,1,2,3,4,5,6,7].map(i=>`<path d="M${140+i*15} 80 l7.5 -9 l7.5 9z" fill="${t==='night'?'#C4B5A8':'#EADCCB'}"/>`).join('')}
    <path d="M185 220 V178 A15 15 0 0 1 215 178 V220Z" fill="#7E151B"/>
    ${windows(112,140,2,1,26,34,12,0,lit,r,true)}${windows(238,140,2,1,26,34,12,0,lit,r,true)}${windows(158,90,3,1,18,24,12,0,lit,r,true)}
    <g fill="#E24C8A" opacity=".85">${[0,1,2,3,4,5,6,7,8].map(i=>`<circle cx="${52+i*10+r()*6}" cy="${196-r()*14}" r="${4+r()*3}"/>`).join('')}</g>`+palm(330,240,110)+palm(70,236,80);
  } else if(kind==='interior'){
    const wall = ['#F4EDE5','#EFE7EA','#ECE9E2'][seed%3];
    body = `<rect width="400" height="300" fill="${wall}"/><rect y="226" width="400" height="74" fill="#D8C2A8"/><path d="M0 226 H400" stroke="#C7AE92" stroke-width="2"/>
    <rect x="200" y="36" width="170" height="150" rx="6" fill="url(#sk${id})"/>${'<g clip-path="url(#cw'+id+')">'+sun(t).replace(/cx="(\d+)"/,'cx="330"')+mountains(t,.55)+'</g>'}
    <rect x="200" y="36" width="170" height="150" rx="6" fill="none" stroke="#fff" stroke-width="8"/><path d="M285 36 V186" stroke="#fff" stroke-width="5"/>
    <rect x="30" y="160" width="170" height="56" rx="18" fill="#B4232A" opacity=".9"/><rect x="40" y="140" width="150" height="40" rx="16" fill="#C9473F"/><rect x="40" y="200" width="10" height="28" fill="#6B4A33"/><rect x="180" y="200" width="10" height="28" fill="#6B4A33"/>
    <ellipse cx="200" cy="262" rx="150" ry="22" fill="#F7941D" opacity=".18"/><rect x="215" y="214" width="90" height="10" rx="5" fill="#6B4A33"/><rect x="225" y="224" width="6" height="22" fill="#6B4A33"/><rect x="290" y="224" width="6" height="22" fill="#6B4A33"/>
    <path d="M110 0 V40" stroke="#6B4A33" stroke-width="2"/><path d="M90 40 h40 l-8 22 h-24z" fill="#F7941D"/>
    <rect x="352" y="200" width="22" height="28" rx="4" fill="#B98B6A"/><g fill="#3E7A4E"><ellipse cx="356" cy="186" rx="10" ry="20"/><ellipse cx="370" cy="180" rx="9" ry="24"/></g>`;
  } else if(kind==='sea'){
    body = mountains(t,.5)+`<path d="M0 170 Q100 160 200 168 T400 164 V300 H0Z" fill="${t==='dusk'?'#5D6F9A':'#4E9CC0'}"/><path d="M0 182 Q100 176 200 182 T400 178" stroke="#fff" stroke-opacity=".5" stroke-width="2" fill="none"/>`+
    `<path d="M0 230 Q120 214 240 226 T400 222 V300 H0Z" fill="#EAD8C0"/>${[0,1,2].map(i=>`<g transform="translate(${70+i*90},${150-r()*6})"><path d="M0 0 h34 l-6 8 h-22z" fill="#fff"/><path d="M16 0 V-26 L28 -4z" fill="#fff" opacity=".9"/></g>`).join('')}
    <rect x="250" y="170" width="120" height="60" fill="#FBF7F1"/>${windows(262,182,4,2,18,14,10,8,lit,r,false)}`+palm(52,262,96)+palm(222,258,70);
  } else if(kind==='shop'){
    const cols=['#B4232A','#F7941D','#3E7A4E'];
    body = mountains(t,.4)+`<rect x="30" y="96" width="340" height="140" fill="${t==='night'?'#CFC4BC':'#FBF7F1'}"/>${windows(50,108,8,1,26,30,14,0,lit,r,true)}
    ${[0,1,2].map(i=>`<rect x="${42+i*110}" y="168" width="96" height="68" fill="#8FB7CC" opacity=".55"/><path d="M${38+i*110} 160 h104 l-8 18 h-88z" fill="${cols[i]}"/><path d="M${38+i*110} 160 h104" stroke="#fff" stroke-dasharray="8 8" stroke-width="10" opacity=".35"/>`).join('')}`+palm(18,250,70);
  } else if(kind==='office'){
    body = mountains(t,.4)+`<rect x="130" y="34" width="140" height="202" fill="url(#gl${id})"/><rect x="250" y="34" width="20" height="202" fill="#000" opacity=".1"/>
    ${Array.from({length:12},(_,i)=>`<path d="M130 ${50+i*16} H270" stroke="#fff" stroke-opacity=".5"/>`).join('')}${Array.from({length:5},(_,i)=>`<path d="M${150+i*24} 34 V236" stroke="#fff" stroke-opacity=".35"/>`).join('')}
    <rect x="40" y="130" width="80" height="106" fill="#FBF7F1"/>${windows(50,142,3,4,16,14,8,8,lit,r,false)}<rect x="282" y="110" width="88" height="126" fill="#F3ECE3"/>${windows(292,122,3,5,18,12,8,8,lit,r,false)}`;
  } else if(kind==='ware'){
    body = mountains(t,.45)+`<path d="M40 236 V130 L200 92 L360 130 V236Z" fill="#E9E1D7"/>${Array.from({length:14},(_,i)=>`<path d="M${50+i*22} ${128-((i<7?i:13-i)*5)} V236" stroke="#CDBFAF" stroke-width="2"/>`).join('')}
    <rect x="150" y="170" width="100" height="66" fill="#B4232A" opacity=".85"/>${Array.from({length:6},(_,i)=>`<path d="M150 ${178+i*10} H250" stroke="#7E151B" stroke-width="2"/>`).join('')}`;
  } else if(kind==='bldg'){
    body = mountains(t,.45)+`<rect x="70" y="70" width="120" height="166" fill="#FBF7F1"/><rect x="210" y="40" width="130" height="196" fill="#F6EFE6"/>${windows(84,84,3,5,22,20,14,10,lit,r,true)}${windows(224,54,4,6,18,18,12,10,lit,r,true)}<rect x="70" y="214" width="270" height="22" fill="#B4232A" opacity=".85"/>`+palm(40,248,80)+palm(366,250,70);
  }
  return `<svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Illustration of ${kind}"><defs>${skyDefs(id,t)}<linearGradient id="gl${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#9CC6DC"/><stop offset="1" stop-color="#E7C6B6"/></linearGradient><clipPath id="cw${id}"><rect x="200" y="36" width="170" height="150" rx="6"/></clipPath></defs>
  ${kind==='interior'?'':`<rect width="400" height="300" fill="url(#sk${id})"/>${sun(t)}`}${body}${kind==='interior'?'':`<rect y="236" width="400" height="64" fill="${ground}"/><rect y="250" width="400" height="10" fill="#000" opacity=".05"/>`}</svg>`;
}

function shot(s, cls){
  if(s[0]==='upload') return `<div class="upl" data-act="upload" role="button" tabindex="0">${ic.plus(26)}<b>Add your photos</b><span>Drag them here or tap to choose</span></div>`;
  if(s[0]==='photo'){ const ph=(window.MPH||{})[s[1]]; if(ph) return `<img${cls?` class="${cls}"`:''} src="${ph.src}" alt="${ph.alt.replace(/"/g,'&quot;')}" loading="lazy" decoding="async">`; s=['tower',7,'day']; }
  const svg = scene(s[0],s[1],s[2]); return cls ? svg.replace('<svg',`<svg class="${cls}"`) : svg;
}
const hasPhoto = p => p.shots[0][0]==='photo';

/* ---------- DATA ---------- */
const P_ALL = [
 {id:1, purpose:'rent', type:'flat', title:'Bright 2-bed near Shatti beach', area:'Shatti Al Qurum', wil:'Bousher', price:400, beds:2, baths:2, sqm:120, furn:false, park:true, agent:true, cheques:4, avail:'15 Oct', x:63, y:47, sea:true, shots:[['photo','shatti']], landlord:'Sulaiman H.'},
 {id:2, purpose:'rent', type:'flat', title:'Compact 1-bed by Muttrah souq', area:'Al Wadi Al Kabeer', wil:'Muttrah', price:90, beds:1, baths:1, sqm:50, furn:false, park:false, agent:false, cheques:12, avail:'Now', x:88, y:58, shots:[['tower',23,'golden'],['interior',4,'golden']], landlord:'Hamad R.'},
 {id:3, purpose:'rent', type:'flat', title:'2-bed in a brand-new building', area:'Al Khuwair 33', wil:'Bousher', price:380, beds:2, baths:2, sqm:110, furn:false, park:true, agent:true, cheques:4, avail:'1 Nov', x:56, y:52, shots:[['photo','khuwair']], landlord:'Al Noor family'},
 {id:4, purpose:'rent', type:'villa', title:'4-bed Omani-style villa', area:'Al Mawaleh South', wil:'Seeb', price:650, beds:4, baths:5, sqm:420, furn:false, park:true, agent:true, cheques:4, avail:'Now', x:33, y:60, shots:[['photo','omani_villa']], landlord:'Khalid S.'},
 {id:5, purpose:'rent', type:'flat', title:'Furnished 2-bed on the marina', area:'Al Mouj', wil:'Seeb', price:620, beds:2, baths:2, sqm:135, furn:true, park:true, agent:true, cheques:2, avail:'Now', x:24, y:38, sea:true, shots:[['sea',59,'day'],['interior',7,'golden'],['sea',60,'dusk']], landlord:'Private owner'},
 {id:6, purpose:'rent', type:'townhouse', title:'3-bed townhouse with roof terrace', area:'Al Hail North', wil:'Seeb', price:550, beds:3, baths:4, sqm:280, furn:false, park:true, agent:false, cheques:4, avail:'20 Oct', x:29, y:47, shots:[['photo','townhouse']], landlord:'Muna A.'},
 {id:7, purpose:'rent', type:'flat', title:'3-bed family flat, 2 min to the beach', area:'Azaiba', wil:'Bousher', price:440, beds:3, baths:3, sqm:165, furn:false, park:true, agent:true, cheques:4, avail:'Now', x:45, y:46, sea:true, shots:[['tower',73,'golden'],['interior',9,'day'],['sea',74,'day']], landlord:'Al Hinai family'},
 {id:8, purpose:'rent', type:'villa', title:'Classic stone-front villa, quiet street', area:'Madinat Sultan Qaboos', wil:'Bousher', price:800, beds:3, baths:4, sqm:350, furn:false, park:true, agent:true, cheques:4, avail:'1 Nov', x:60, y:56, shots:[['photo','msq_villa']], landlord:'Ahmed B.'},
 {id:9, purpose:'rent', type:'office', title:'Grade A office floor', area:'Ghubra', wil:'Bousher', price:900, beds:0, baths:2, sqm:240, furn:false, park:true, agent:true, cheques:4, avail:'Now', x:51, y:49, shots:[['office',91,'day'],['office',92,'dusk']], landlord:'Ghubra Holdings'},
 {id:10, purpose:'rent', type:'shop', title:'Corner shop on a busy street', area:'Ruwi', wil:'Muttrah', price:350, beds:0, baths:1, sqm:60, furn:false, park:false, agent:false, cheques:4, avail:'Now', x:83, y:64, shots:[['shop',101,'day'],['shop',102,'night']], landlord:'Ruwi Trading'},
 {id:11, purpose:'sale', type:'flat', title:'Sea-view 2-bed apartment, freehold', area:'Al Mouj', wil:'Seeb', price:115000, beds:2, baths:2, sqm:128, furn:true, park:true, agent:true, cheques:0, avail:'Ready', x:22, y:34, sea:true, shots:[['sea',111,'golden'],['interior',11,'day']], landlord:'Private owner'},
 {id:12, purpose:'sale', type:'villa', title:'4-bed villa with private pool, freehold', area:'Muscat Bay', wil:'Muscat', price:285000, beds:4, baths:5, sqm:390, furn:false, park:true, agent:true, cheques:0, avail:'Ready', x:93, y:70, sea:true, shots:[['photo','pool_villa']], landlord:'Private owner'},
 {id:15, purpose:'rent', type:'villa', title:'Modern 5-bed villa with garden', area:'Al Mouj', wil:'Seeb', price:1400, beds:5, baths:6, sqm:520, furn:false, park:true, agent:true, cheques:4, avail:'1 Nov', x:26, y:41, sea:true, shots:[['photo','modern_villa']], landlord:'Private owner'},
 {id:13, purpose:'sale', type:'bldg', title:'Whole building, 12 units, fully let', area:'Al Amerat', wil:'Al Amerat', price:420000, beds:0, baths:0, sqm:1600, furn:false, park:true, agent:true, cheques:0, avail:'Ready', x:78, y:80, shots:[['bldg',131,'day'],['bldg',132,'dusk']], landlord:'Al Rawahi family'},
 {id:14, purpose:'rent', type:'ware', title:'Warehouse with loading bay', area:'Rusayl', wil:'Seeb', price:1200, beds:0, baths:1, sqm:800, furn:false, park:true, agent:false, cheques:4, avail:'Now', x:40, y:74, shots:[['ware',141,'day']], landlord:'Rusayl Logistics'}
];
const P = P_ALL.filter(hasPhoto);
const TYPES = [['all','All',ic.all],['flat','Flats',ic.flat],['villa','Villas',ic.villa],['townhouse','Townhouses',ic.town],['shop','Shops',ic.shop],['office','Offices',ic.office],['ware','Warehouses',ic.ware],['bldg','Buildings',ic.bldg]];
const AREAS = [['Al Mouj','Seeb',600,['photo','modern_villa'],'span2 row2'],['Madinat Sultan Qaboos','Bousher',520,['photo','msq_villa'],''],['Shatti Al Qurum','Bousher',560,['photo','shatti'],''],['Al Khuwair','Bousher',240,['photo','khuwair'],'span2']];

/* ---------- HELPERS ---------- */
const $ = (s,el=document)=>el.querySelector(s);
const $$ = (s,el=document)=>Array.from(el.querySelectorAll(s));
const fmt = n => n.toLocaleString('en-US');
const money = p => p.purpose==='sale' ? `OMR ${fmt(p.price)}` : `OMR ${fmt(p.price)}`;
const per = p => p.purpose==='sale' ? '' : '<small> / month</small>';
const typeName = t => ({flat:'Flat',villa:'Villa',townhouse:'Townhouse',shop:'Shop',office:'Office',ware:'Warehouse',bldg:'Building'})[t];
const state = { saved: new Set(), purpose:'rent', ai:null, filters:{type:'all',max:null,beds:0,agent:false,furn:false,sort:'match'}, cleanups:[] };
function toast(msg, icon){ const t=$('#toast'); t.innerHTML=(icon||ic.check(16))+'<span>'+msg+'</span>'; t.classList.add('show'); clearTimeout(t._h); t._h=setTimeout(()=>t.classList.remove('show'),2600); }
function every(fn,ms){ const h=setInterval(fn,ms); state.cleanups.push(()=>clearInterval(h)); return h; }
function later(fn,ms){ const h=setTimeout(fn,ms); state.cleanups.push(()=>clearTimeout(h)); return h; }
function go(h){ if(location.hash===h){ route(); } else { location.hash=h; } }
function esc(s){ return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
/* ---------- SHELL ---------- */
function renderNav(route){
  const dark = route==='owners';
  const nav = $('#nav'); nav.classList.toggle('dark', dark);
  const on = r => route===r ? 'on' : '';
  nav.innerHTML = `<div class="wrap nav-in">
    <a href="#/" class="brand" aria-label="Mumtalikati home">${logo(40,'navlogo')}<span class="brand-text"><b>ممتلكاتي</b></span></a>
    <nav class="nav-links" aria-label="Main">
      <a href="#/search?p=rent" class="${route==='search'&&state.purpose==='rent'?'on':''}">Rent</a>
      <a href="#/search?p=sale" class="${route==='search'&&state.purpose==='sale'?'on':''}">Buy</a>
      <a href="#/owners" class="${on('owners')}">AI agent for owners</a>
      <a href="#/owners?s=pricing">Pricing</a>
      <a href="#/news" class="${on('news')}">News</a>
    </nav>
    <div class="nav-actions">
      <button class="icon-btn hide-m ar" data-act="lang" aria-label="Switch to Arabic" style="font-size:14px;font-weight:600">ع</button>
      <button class="icon-btn hide-m" data-act="theme" aria-label="Toggle dark mode">${document.documentElement.dataset.theme==='dark'?ic.sun(19):ic.moon(19)}</button>
      <button class="icon-btn" data-act="saved" aria-label="Saved properties">${ic.heart(20)}<span class="count ${state.saved.size?'show':''}" id="savedCount">${state.saved.size}</span></button>
      <a href="#/list" class="btn btn-primary btn-sm hide-m">List free ${ic.arrow(16)}</a>
      <button class="icon-btn menu-btn" data-act="menu" aria-label="Open menu">${ic.menu(22)}</button>
    </div></div>`;
}
function renderFooter(){
  $('#footer').innerHTML = `<div class="marquee" aria-hidden="true"><span>Muscat · Seeb · Bousher · Muttrah · Al Amerat · Salalah · Sohar · Nizwa ·</span><span>Muscat · Seeb · Bousher · Muttrah · Al Amerat · Salalah · Sohar · Nizwa ·</span></div>
  <div class="wrap"><div class="fcols">
    <div><a href="#/" class="brand" style="color:#fff" aria-label="Mumtalikati home">${logo(40,'ftlogo')}<span class="brand-text" style="border-color:rgba(255,255,255,.2)"><b style="color:#FF8A73">ممتلكاتي</b></span></a>
      <p style="margin:18px 0 14px;max-width:26em">Oman's property platform with an AI agent built in. GCC U11, B360, South Mawaleh, Muscat.</p>
      <div class="stores"><a class="store" href="#/" data-act="store">${ic.apple(18)}<span>App Store</span></a><a class="store" href="#/" data-act="store">${ic.play(16)}<span>Google Play</span></a></div></div>
    <div><h5>Find</h5><a href="#/search?p=rent">Homes for rent</a><a href="#/search?p=sale">Homes for sale</a><a href="#/search?p=rent&t=office">Offices and shops</a><a href="#/search?p=sale&t=bldg">Whole buildings</a></div>
    <div><h5>Owners</h5><a href="#/owners">AI agent</a><a href="#/owners?s=pricing">Pricing</a><a href="#/list">List a property</a><a href="#/owners?s=faq">Questions</a><a href="#/news">Property news</a></div>
    <div><h5>Talk to us</h5><a href="#/" data-act="wa">WhatsApp +968 9916 0109</a><a href="#/" data-act="wa">Become a service provider</a><a href="#/" data-act="wa">Privacy</a></div>
  </div><p style="margin:50px 0 0;font-size:13px;opacity:.7">Prototype for review. Listings, names and figures are samples.</p></div>`;
}

/* ---------- CARD ---------- */
function card(p, o={}){
  const saved = state.saved.has(p.id);
  const slides = p.shots.map(s=>`<div>${shot(s)}</div>`).join('');
  const dots = p.shots.length>1 ? `<div class="pc-dots">${p.shots.map((_,i)=>`<i class="${i?'':'on'}"></i>`).join('')}</div>` : '';
  const badge = p.agent ? `<span class="pill pill-glass"><span class="dot"></span>AI agent</span>` : `<span class="pill pill-glass">${ic.shield(14)} Verified landlord</span>`;
  const spec = p.beds ? `<span>${ic.bed()} ${p.beds} bed</span><span>${ic.bath()} ${p.baths} bath</span>` : `<span>${typeName(p.type)}</span>`;
  return `<article class="pcard ${o.cls||''}" data-open="${p.id}" data-id="${p.id}" style="${o.style||''}" tabindex="0" aria-label="${esc(p.title)}, ${money(p)}">
    <div class="pc-media" data-slide="0">
      <div class="pc-track">${slides}</div>
      <div class="pc-top">${badge}<button class="heart ${saved?'on':''}" data-save="${p.id}" aria-label="${saved?'Remove from saved':'Save property'}">${saved?ic.heartF(18):ic.heart(18)}</button></div>
      ${p.shots.length>1?`<button class="pc-nav l" data-nav="-1" aria-label="Previous photo">${ic.left(16)}</button><button class="pc-nav r" data-nav="1" aria-label="Next photo">${ic.right(16)}</button>`:''}
      ${dots}${o.match?`<span class="pill pill-glass match" style="right:auto">${ic.spark(14)} ${o.match}% match</span>`:''}
    </div>
    <div class="pc-body">
      <div class="pc-price">${money(p)}${per(p)}</div>
      <div class="pc-title">${esc(p.title)}</div>
      <div class="pc-loc">${ic.pin(14)} ${esc(p.area)}, ${esc(p.wil)}</div>
      <div class="pc-specs">${spec}<span>${ic.size()} ${fmt(p.sqm)} sqm</span></div>
    </div></article>`;
}

/* ---------- HOME ---------- */
const HINTS = ['2-bed flat in Bousher under 450 with parking','Villa in Seeb for a family of five','Townhouse in Al Hail with a garden','Buy a villa with a pool, freehold','Villa in Madinat Sultan Qaboos under 900'];
const PMS_FEED=[
 ['rent','cheque','Rent collected','OMR 450 received from Ahmed Al Balushi, Flat 12B, Al Khuwair. Receipt sent.'],
 ['neg','chat','Negotiation','Tenant offered OMR 820 for the Qurum villa. Your floor is 850, so the agent countered at 860.'],
 ['mnt','wrench','Maintenance alert','AC fault reported at Bousher Heights 4A. Technician booked for today, 4 to 6 pm.'],
 ['lease','doc','Lease signed','12-month contract for Seeb townhouse signed and filed with Muscat Municipality.'],
 ['view','cal','Viewing booked','Fatma confirmed Tuesday 5 pm for the Madinat Sultan Qaboos villa.'],
 ['rent','bolt','Reminder sent','Rent due in 3 days for Al Hail shop 7. Polite WhatsApp reminder delivered.'],
 ['neg','check','Deal agreed','Office in Ruwi let at OMR 1,150 a month with a 2-cheque plan. Within your rules.'],
 ['mnt','shield','Inspection due','Annual fire safety check for Al Mouj tower is due next week. Vendor quotes ready.'],
 ['rent','cheque','Cheque cleared','PDC 3 of 4 cleared for Azaiba villa. OMR 2,100 now in your account.'],
 ['lease','key','Renewal offer','Lease at Al Ghubra 9C ends in 60 days. Renewal at +3% sent for approval.'],
 ['view','users','New enquiry','2 families asked about the Seeb villa in the last hour. Agent is pre-screening.'],
 ['mnt','wrench','Ticket closed','Water leak at Mawaleh flat fixed. Tenant rated the repair 5 stars.']
];
const PMS_FEED_T=['09:12','09:14','09:17','09:21','09:24','09:28','09:31','09:35','09:38','09:42','09:45','09:49'];
function agentStage(){
  const sc=(i,cls,cap,time,viz)=>`<div class="scn ${cls}" style="--dl:${i*4}s"><div class="scn-cap"><b>${cap}</b><span>${time}</span></div><div class="scn-viz">${viz}</div></div>`;
  const a=(d)=>`class="a" style="animation-delay:calc(var(--dl) + ${d}s)"`;
  const A=(c,d,extra='')=>`class="a ${c}" style="animation-delay:calc(var(--dl) + ${d}s);${extra}"`;
  return `<div class="stage-v" aria-hidden="true"><span class="rec"><i></i>AGENT AT WORK</span>
  ${sc(0,'k-rent','<span style="color:#6BE0A4">Collecting rent</span>','Flat 12B · Al Khuwair',
    `<div class="wallet"></div>${[14,40,62].map((x,j)=>`<span ${A('coin',j*.35,`left:${x}px`)}></span>`).join('')}
     <div class="amt"><b>OMR 450</b><span>Ahmed Al Balushi · bank transfer</span><div class="track"><i ${a(0)}></i></div></div>
     <div ${A('okb',0)}><span>${ic.check(14)}</span>Received, receipt sent</div>`)}
  ${sc(1,'k-neg','<span style="color:#FFB27A">Negotiating</span>','Villa · Qurum',
    `<div ${A('bub t',0)}>Can you do OMR 820 a month?</div><div ${A('bub g',0)}>Best I can do is 860, with AC service included.</div>
     <div class="scale"><div class="ln"></div><span ${A('mk ten',0)}>820</span><span class="mk flo">floor 850</span><span ${A('mk ctr',0)}>860</span></div>`)}
  ${sc(2,'k-mnt','<span style="color:#FF8A73">Maintenance alert</span>','Bousher Heights 4A',
    `<div class="ac"></div><span class="alarm"></span><div class="road"><span ${A('van',0)}>${ic.wrench(14)}</span></div>
     <div class="steps3"><div ${a(0)}><b>Reported</b>AC not cooling</div><div ${a(0)}><b>Booked</b>Today 4 to 6 pm</div><div ${a(0)}><b>On the way</b>ETA 12 min</div></div>`)}
  ${sc(3,'k-lease','<span style="color:#A9C1FF">Signing lease</span>','Townhouse · Seeb',
    `<div class="docu"><i style="width:70%"></i><i></i><i style="width:85%"></i><i style="width:55%"></i><svg viewBox="0 0 100 36"><path ${a(0)} d="M4 26c8-14 14-18 16-12s-6 14 2 10 10-16 16-14-4 14 4 12 8-10 14-8 4 8 10 6 10-6 14-4 8 2 14 0"/></svg></div>
     <div ${A('stamp',0)}>SIGNED</div>
     <div class="lmeta"><b>12-month lease</b><span ${a(0)}>OMR 520 a month · 4 cheques</span><span ${a(.2)}>Filed with Muscat Municipality</span></div>`)}
  ${sc(4,'k-view','<span>Booking a viewing</span>','Villa · MSQ',
    `<div class="cal">${[['Sun',2],['Mon',3],['Tue',4],['Wed',5],['Thu',6]].map(([d,n])=>`<div ${d==='Tue'?A('on',0):''}>${d}<b>${n}</b></div>`).join('')}</div>
     <div class="mini-map"><span ${A('pn',0)}>${ic.pin(24)}</span></div>
     <div ${A('vconf',0)}><span>${ic.check(13)}</span>Fatma confirmed Tue 4 Nov, 5 pm</div>`)}
  <div class="segs"><i></i><i></i><i></i><i></i><i></i></div></div>`;
}
function liveFeed(){
  const row=(f,i)=>`<div class="fe k-${f[0]}"><span class="fi">${ic[f[1]](16)}</span><div style="min-width:0;flex:1"><div class="fm"><b>${f[2]}</b><span>${PMS_FEED_T[i]}</span></div>${f[3]}</div></div>`;
  const items=PMS_FEED.map(row).join('');
  return `<div class="feed" aria-label="Live activity from the Mumtalikati Property Manager"><div class="feed-head"><b><span class="ai-badge">AI</span> Mumtalikati Property Manager</b><span class="live"><span class="dot"></span>LIVE</span></div>${agentStage()}<div class="feed-win"><div class="feed-track">${items}<div aria-hidden="true" style="display:contents">${items}</div></div></div></div>`;
}
function home(){
  const featured = P.filter(p=>p.purpose==='rent').sort((a,b)=>hasPhoto(b)-hasPhoto(a)).slice(0,8);
  return `<div class="page">
  <section class="hero">
    <div class="orb o1"></div><div class="orb o2"></div><div class="orb o3"></div><div class="grain"></div>
    <div class="wrap hero-grid">
      <div>
        <span class="pill pill-ai reveal"><span class="dot"></span>New: the Mumtalikati AI agent</span>
        <p class="hero-ar ar reveal" dir="rtl" style="--d:.05s;margin:22px 0 0;text-align:left">ابحث، استأجر، ودع الذكاء الاصطناعي يدير عقارك</p>
        <h1 class="reveal" style="--d:.1s">Find your place in Oman. <span class="serif grad-text">Let AI</span> handle the rest.</h1>
        <p class="hero-sub reveal" style="--d:.18s">Search homes, shops and offices in plain words. Owners get an AI agent that lets, collects and settles, always inside their rules.</p>
        <form class="ai-box reveal" style="--d:.26s" data-form="ai">
          <div class="ai-row">
            <div class="seg" role="group" aria-label="Rent or buy"><button type="button" class="${state.purpose==='rent'?'on':''}" data-purpose="rent">Rent</button><button type="button" class="${state.purpose==='sale'?'on':''}" data-purpose="sale">Buy</button></div>
            <label class="sr" for="aiq">Describe what you are looking for</label>
            <input class="ai-input" id="aiq" name="q" autocomplete="off" placeholder="${HINTS[0]}">
            <button class="ai-go" aria-label="Search with AI">${ic.spark(22)}</button>
          </div>
        </form>
        <div class="ai-hints reveal" style="--d:.34s"><span class="spark">${ic.spark(15)} Try</span>${HINTS.slice(0,3).map(h=>`<button class="chip" data-hint="${esc(h)}">${esc(h)}</button>`).join('')}</div>
      </div>
      <div class="feed-col reveal" style="--d:.3s">${liveFeed()}</div>
    </div>
  </section>

  <section class="wrap" style="padding-bottom:40px">
    <div style="display:flex;justify-content:space-between;align-items:flex-end;gap:20px;flex-wrap:wrap" class="reveal">
      <div><span class="eyebrow">Fresh this week</span><h2 class="h2" style="font-size:clamp(30px,3.4vw,46px)">Homes and spaces across Muscat</h2></div>
      <div style="display:flex;gap:8px"><button class="icon-btn" style="border:1px solid var(--line-strong)" data-rail="-1" aria-label="Scroll left">${ic.left()}</button><button class="icon-btn" style="border:1px solid var(--line-strong)" data-rail="1" aria-label="Scroll right">${ic.right()}</button></div>
    </div>
    <div class="cats reveal" style="margin-top:26px" role="tablist">${TYPES.filter(([k])=>k==='all'||P.some(p=>p.purpose==='rent'&&p.type===k)).map(([k,l,f])=>`<button class="cat ${k==='all'?'on':''}" data-homecat="${k}" role="tab">${f()}<span>${l}</span></button>`).join('')}</div>
    <div class="rail" id="homeRail">${featured.map(p=>card(p)).join('')}</div>
    <div class="reveal" style="text-align:center;margin-top:10px"><a href="#/search?p=rent" class="btn btn-ghost">Browse all properties ${ic.arrow(16)}</a></div>
  </section>

  <section class="section wrap">
    <div class="reveal"><span class="eyebrow">Explore by area</span><h2 class="h2">Where do you want to live?</h2><p class="lead">Typical monthly rent for a 2-bedroom flat, from 2026 market guides.</p></div>
    <div class="bento-areas">${AREAS.map(([n,w,r,s,c],i)=>`<a href="#/search?p=rent&a=${encodeURIComponent(n)}" class="area reveal ${c}" style="--d:${i*.06}s">${shot(s,'bg')}<span class="a-name">${n}</span><span class="a-meta"><span>${w} · from OMR ${r}</span><span class="a-go">${ic.arrow(16)}</span></span></a>`).join('')}</div>
  </section>

  <section class="section" style="padding-top:20px">
    <div class="wrap">
      <div class="reveal" style="text-align:center"><span class="eyebrow">One platform, two sides</span><h2 class="h2">An AI agent working for <span class="serif grad-text">everyone</span> in the deal.</h2></div>
      <div class="dual">
        <div class="panel light reveal">
          <span class="pill pill-red" style="align-self:flex-start">For tenants and buyers</span>
          <h3>Answers in minutes, at any hour.</h3>
          <ul class="ticks"><li>${ic.check()}Ask about parking, cheques or move-in dates in Arabic or English</li><li>${ic.check()}Book a viewing straight into the owner's calendar</li><li>${ic.check()}Make an offer and get a real answer, not silence</li><li>${ic.check()}Every listing checked: owner identity and availability confirmed</li></ul>
          <a href="#/search?p=rent" class="btn btn-primary" style="align-self:flex-start;margin-top:auto">Start searching ${ic.arrow(16)}</a>
        </div>
        <div class="panel dark reveal" style="--d:.1s">
          <div class="orb" style="width:360px;height:360px;background:#E2462C;top:-140px;right:-120px;opacity:.35"></div>
          <span class="pill" style="align-self:flex-start;background:rgba(247,148,29,.16);color:#FFB27A">For owners</span>
          <h3>An AI agent that runs your property.</h3>
          <ul class="ticks"><li>${ic.check()}Tracks every post-dated cheque and follows up on late rent</li><li>${ic.check()}Books repairs, renews leases and keeps tenants happy</li><li>${ic.check()}Settles income with each family shareholder</li><li>${ic.check()}Acts inside your limits and asks you about everything else</li></ul>
          <a href="#/owners" class="btn btn-light" style="align-self:flex-start;margin-top:auto">Meet the AI agent ${ic.arrow(16)}</a>
        </div>
      </div>
    </div>
  </section>

  <section class="night section">
    <div class="orb" style="width:600px;height:600px;background:#B4232A;top:-260px;left:-200px;opacity:.35"></div>
    <div class="wrap two" id="vacBand">
      <div class="reveal"><span class="eyebrow">For landlords</span><h2 class="h2">Every empty month is rent you never get back.</h2><p class="lead">Older buildings in Muscat often sit empty for weeks between tenants. See what that costs you, then see what the agent does about it.</p>
        <a href="#/owners?s=calc" class="btn btn-primary" style="margin-top:30px">See what managing it costs you ${ic.arrow(16)}</a></div>
      <div class="reveal" style="--d:.1s">${consoleMarkup()}</div>
    </div>
  </section>

  ${homeNews()}

  <section class="section wrap two-b">
    <div class="reveal"><span class="eyebrow">From the community</span>
      <p style="font-size:clamp(28px,3.2vw,44px);line-height:1.15;letter-spacing:-.03em;font-weight:500;margin:18px 0 0">“Spacious apartment with great lighting.”</p>
      <p class="muted" style="margin-top:14px">Faheem A., tenant review on Mumtalikati</p></div>
    <div class="panel light reveal" style="min-height:auto;--d:.1s"><h3 style="font-size:26px">Take Mumtalikati with you</h3><p class="muted" style="margin:0">Search, chat with the agent and pay rent from your phone.</p>
      <div style="display:flex;gap:10px;flex-wrap:wrap"><a class="btn btn-ghost" href="#/" data-act="store">${ic.apple(18)} App Store</a><a class="btn btn-ghost" href="#/" data-act="store">${ic.play(16)} Google Play</a></div></div>
  </section>
  </div>`;
}
function miniCard(p){ return `<div class="mini-card"><div class="m-img">${shot(p.shots[0])}</div><div class="m-body"><div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:17px">${money(p)}</b><span class="pill pill-ai" style="padding:4px 9px;font-size:11px"><span class="dot"></span>AI</span></div><div style="font-size:13px" class="muted">${esc(p.title)}</div></div></div>`; }

/* Live agent console (used on home + owners) */
const FEED = [
  ['cheque','Deposited Flat 1C\'s October cheque, OMR 280. Cleared.'],
  ['key','Relisted Flat 2A, 60 days before its lease ends. 9 enquiries so far.'],
  ['chat','Answered 14 tenant questions overnight in Arabic and English.'],
  ['shield','Checked ID and salary letters. Shortlisted 2 tenants for Flat 2A.'],
  ['wrench','AC fault in Flat 4B. Booked a 4.8-rated technician for 4 pm, OMR 18, within your limit.'],
  ['doc','Prepared the lease for Flat 5A and filed it for registration.']
];
function consoleMarkup(){ return `<div class="console" data-console><div class="c-head"><div><b style="font-size:15px">Al Noor Building, Bousher</b><div style="font-size:12.5px;color:var(--night-muted)">14 units · AI agent</div></div><span class="pill" style="background:rgba(247,148,29,.16);color:#FFB27A"><span class="dot"></span>Working now</span></div><div data-feed></div></div>`; }
function runConsole(root){
  const el = $('[data-feed]',root); if(!el) return; let i=0; const t0=['08:40','09:12','09:31','09:55','10:31','10:48'];
  const step=()=>{
    if(i<4){ const f=FEED[(i+(root._off||0))%FEED.length]; el.insertAdjacentHTML('beforeend',`<div class="c-line"><span class="t">${t0[i]}</span><span class="c-ico">${ic[f[0]](16)}</span><span>${f[1]}</span></div>`); i++; }
    else if(i===4){ el.insertAdjacentHTML('beforeend',`<div class="decision"><div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:6px"><b style="color:#FFB27A">Needs your decision</b><span style="color:var(--night-muted)">11:02</span></div><div style="font-size:14.5px">Ahmed offers OMR 380 for Flat 3B, 12 months, 4 cheques. Similar flats let for 390 to 410. I suggest countering at 395.</div><div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap" data-dec><button class="btn btn-primary btn-sm" data-decide="counter">Counter at 395</button><button class="btn btn-outline-light btn-sm" data-decide="accept">Accept 380</button></div></div>`); i++; }
    else if(i>=10){ el.innerHTML=''; i=0; root._off=(root._off||0)+2; }
    else i++;
  };
  step(); every(step,1600);
}
/* ---------- AI QUERY PARSER ---------- */
const AREA_WORDS = {'al mouj':'Al Mouj','mouj':'Al Mouj','khuwair':'Al Khuwair','azaiba':'Azaiba','azaibah':'Azaiba','qurum':'Shatti Al Qurum','shatti':'Shatti Al Qurum','mawaleh':'Al Mawaleh','hail':'Al Hail','ghubra':'Ghubra','muttrah':'Muttrah','mutrah':'Muttrah','ruwi':'Ruwi','seeb':'Seeb','bousher':'Bousher','bawshar':'Bousher','amerat':'Al Amerat','msq':'Madinat Sultan Qaboos','sultan qaboos':'Madinat Sultan Qaboos','rusayl':'Rusayl'};
const TYPE_WORDS = [[/\b(flat|flats|apartment|apartments|studio)\b/,'flat'],[/\bvillas?\b/,'villa'],[/\btown ?houses?\b/,'townhouse'],[/\bshops?\b|\bretail\b/,'shop'],[/\boffices?\b/,'office'],[/\bwarehouses?\b|\bstorage\b/,'ware'],[/\b(whole )?buildings?\b/,'bldg']];
function parseQuery(q){
  const s = (q||'').toLowerCase(); const f = {};
  if(/\b(buy|sale|purchase|freehold|own)\b/.test(s)) f.purpose='sale'; else if(/\b(rent|lease|rental)\b/.test(s)) f.purpose='rent';
  const b = s.match(/(\d)\s*-?\s*(bed|bedroom|bedrooms|br|bhk)/); if(b) f.beds=+b[1];
  const fam = s.match(/family of (\w+)/); if(fam && !f.beds) f.beds=3;
  const m = s.match(/(?:under|below|max|up to|less than|budget|<)\s*(?:omr|ro|rial|rials)?\s*([\d,.]+)\s*(k)?/); if(m){ let v=parseFloat(m[1].replace(/,/g,'')); if(m[2]) v*=1000; f.max=v; }
  for(const [re,t] of TYPE_WORDS){ if(re.test(s)){ f.type=t; break; } }
  for(const k of Object.keys(AREA_WORDS)){ if(s.includes(k)){ f.area=AREA_WORDS[k]; break; } }
  if(/furnished/.test(s) && !/unfurnished/.test(s)) f.furn=true;
  if(/parking|car park|garage/.test(s)) f.park=true;
  if(/beach|sea|marina|waterfront/.test(s)) f.sea=true;
  return f;
}
function inArea(p,a){ if(!a) return true; return p.area.includes(a)||p.wil===a||a.includes(p.area); }
function results(){
  const f = state.filters, ai = state.ai||{};
  let r = P.filter(p=>p.purpose===state.purpose)
    .filter(p=>f.type==='all'||p.type===f.type)
    .filter(p=>!f.max||p.price<=f.max)
    .filter(p=>!f.beds||p.beds>=f.beds)
    .filter(p=>!f.agent||p.agent)
    .filter(p=>!f.furn||p.furn)
    .filter(p=>!f.park||p.park)
    .filter(p=>!f.sea||p.sea)
    .filter(p=>inArea(p,f.area));
  r = r.map(p=>{ let m = 90 + (p.agent?4:0) + (f.max? Math.max(-14, Math.round(4 - Math.abs(p.price - f.max*0.88)/f.max*30)) : 3) + (p.id%3); return {p, match: Math.max(72, Math.min(99, m))}; });
  if(f.sort==='low') r.sort((a,b)=>a.p.price-b.p.price); else if(f.sort==='high') r.sort((a,b)=>b.p.price-a.p.price); else r.sort((a,b)=>(hasPhoto(b.p)-hasPhoto(a.p))||(b.match-a.match));
  return r;
}
function chipsFor(f){
  const out=[]; if(f.purpose) out.push(f.purpose==='sale'?'To buy':'To rent'); if(f.beds) out.push(f.beds+'+ bedrooms'); if(f.type) out.push(typeName(f.type)); if(f.area) out.push(f.area); if(f.max) out.push('Up to OMR '+fmt(f.max)); if(f.furn) out.push('Furnished'); if(f.park) out.push('Parking'); if(f.sea) out.push('Near the sea'); return out;
}

/* ---------- SEARCH PAGE ---------- */
const MAXES = {rent:[150,300,450,600,900,1500], sale:[100000,150000,300000,500000]};
function searchPage(qs){
  state.purpose = qs.get('p')==='sale'?'sale':'rent';
  const q = qs.get('q')||'';
  const f = state.filters = {type:qs.get('t')||'all',max:null,beds:0,agent:false,furn:false,park:false,sea:false,area:qs.get('a')||'',sort:'match'};
  state.ai = null;
  if(q){ const a = parseQuery(q); state.ai=a; if(a.purpose) state.purpose=a.purpose; Object.assign(f,{type:a.type||f.type,max:a.max||null,beds:a.beds||0,furn:!!a.furn,park:!!a.park,sea:!!a.sea,area:a.area||f.area}); }
  const opt = (v,l,cur)=>`<option value="${v}" ${String(cur)===String(v)?'selected':''}>${l}</option>`;
  return `<div class="page" style="padding-top:76px">
  <div class="fbar"><div class="wrap fbar-in">
    <form class="ai-mini" data-form="aimini"><span style="color:var(--red)">${ic.spark(18)}</span><label class="sr" for="aimq">Search with AI</label><input id="aimq" name="q" value="${esc(q)}" placeholder="Describe it, e.g. 3-bed near the beach under 500" autocomplete="off"><button class="send" aria-label="Search">${ic.search(17)}</button></form>
    <div class="frow">
    <div class="seg" role="group" aria-label="Rent or buy"><button class="${state.purpose==='rent'?'on':''}" data-spurpose="rent">Rent</button><button class="${state.purpose==='sale'?'on':''}" data-spurpose="sale">Buy</button></div>
    <select class="select" data-f="type" aria-label="Property type">${TYPES.map(([k,l])=>opt(k,k==='all'?'Any type':l,f.type)).join('')}</select>
    <select class="select" data-f="max" aria-label="Maximum price">${opt('','Any price',f.max||'')}${MAXES[state.purpose].map(v=>opt(v,'Up to OMR '+fmt(v),f.max||'')).join('')}${f.max&&!MAXES[state.purpose].includes(f.max)?opt(f.max,'Up to OMR '+fmt(f.max),f.max):''}</select>
    <select class="select" data-f="beds" aria-label="Bedrooms">${[0,1,2,3,4].map(v=>opt(v,v?v+'+ beds':'Any beds',f.beds)).join('')}</select>
    <button class="toggle ${f.agent?'on':''}" data-tog="agent"><span class="sw"></span>AI agent</button>
    <button class="toggle ${f.furn?'on':''}" data-tog="furn"><span class="sw"></span>Furnished</button>
    </div>
  </div></div>
  <div class="wrap">
    ${state.ai?`<div class="understood"><span style="display:inline-flex;gap:8px;align-items:center;font-weight:600">${ic.spark(16)} Understood:</span>${chipsFor(Object.assign({purpose:state.purpose},state.ai)).map(c=>`<span class="chip">${esc(c)}</span>`).join('')}<button class="link-arrow" style="margin-left:auto;font-size:14px" data-act="clearai">Clear</button></div>`:''}
    ${f.area&&!state.ai?`<div class="understood"><span style="font-weight:600">Area:</span><span class="chip">${esc(f.area)}</span><button class="link-arrow" style="margin-left:auto;font-size:14px" data-act="cleararea">Show all areas</button></div>`:''}
    <div class="slayout">
      <div>
        <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px">
          <div><h1 style="margin:0;font-size:30px;letter-spacing:-.03em;font-weight:600" id="sTitle"></h1><span class="muted" style="font-size:14px" id="sCount"></span></div>
          <div style="display:flex;gap:8px"><select class="select" data-f="sort" aria-label="Sort">${opt('match','Best match',f.sort)}${opt('low','Price, low to high',f.sort)}${opt('high','Price, high to low',f.sort)}</select></div>
        </div>
        <div class="grid2" id="results"></div>
      </div>
      <div class="mapbox" id="mapbox">${mapSvg()}<div id="pins"></div>
        <div class="map-legend"><span class="pill pill-glass"><span class="dot"></span>AI agent listing</span><span class="pill pill-glass">Muscat Governorate</span></div></div>
    <button class="map-fab" data-act="mapm">${ic.map(16)} Map</button>
    </div>
  </div></div>`;
}
function mapSvg(){ return `<svg class="map" viewBox="0 0 460 600" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
  <rect width="460" height="600" fill="#EFE5DC"/>
  <path d="M0 0 H460 V250 Q420 270 380 262 Q330 250 300 268 Q260 290 220 262 Q180 236 140 240 Q90 246 60 222 Q30 200 0 210Z" fill="#BFDDEB"/>
  <path d="M0 210 Q30 200 60 222 Q90 246 140 240 Q180 236 220 262 Q260 290 300 268 Q330 250 380 262 Q420 270 460 250" fill="none" stroke="#fff" stroke-width="3" opacity=".7"/>
  <g fill="none" stroke="#fff" stroke-width="9" stroke-linecap="round"><path d="M-10 330 Q120 300 240 326 T470 330"/><path d="M60 600 Q90 450 140 300"/><path d="M260 600 Q250 450 270 300"/><path d="M380 600 Q370 470 400 290"/></g>
  <g fill="none" stroke="#fff" stroke-width="4" opacity=".8"><path d="M-10 420 Q200 400 470 440"/><path d="M180 600 Q170 480 200 330"/></g>
  <g fill="#D9C8B6" opacity=".7"><path d="M300 470 l40 -60 l30 40 l40 -70 l60 110 v120 h-170z"/><path d="M380 520 l30 -40 l30 30 l30 -40 v130 h-90z"/></g>
  <g font-family="Poppins,sans-serif" font-size="12" fill="#8A7B76" font-weight="500"><text x="60" y="180">Gulf of Oman</text><text x="70" y="280">Seeb</text><text x="220" y="300">Bousher</text><text x="370" y="300">Muttrah</text><text x="330" y="500">Al Amerat</text></g>
  </svg>`; }
function renderResults(){
  const r = results(); const box=$('#results'); if(!box) return;
  const f=state.filters;
  $('#sTitle').textContent = (f.type==='all'?'Properties':typeName(f.type)+'s')+(state.purpose==='sale'?' for sale':' for rent')+(f.area?' in '+f.area:' in Muscat');
  $('#sCount').textContent = r.length+' result'+(r.length===1?'':'s')+', '+r.filter(x=>x.p.agent).length+' with the AI agent';
  box.innerHTML = r.length ? r.map((x,i)=>card(x.p,{match: state.ai?x.match:null, style:`animation:lineIn .6s var(--ease) ${i*.05}s both`})).join('') :
    `<div class="empty" style="grid-column:1/-1"><div style="font-size:22px;font-weight:600">Nothing matches yet</div><p class="muted">Loosen a filter, or let the agent message you when a match is listed.</p><button class="btn btn-primary" data-act="alert">${ic.bolt(16)} Alert me</button></div>`;
  $('#pins').innerHTML = r.map(x=>`<button class="pin ${x.p.agent?'ai':''}" data-pin="${x.p.id}" style="left:${x.p.x}%;top:${x.p.y}%" aria-label="${esc(x.p.title)}">${x.p.purpose==='sale'?'OMR '+Math.round(x.p.price/1000)+'k':'OMR '+fmt(x.p.price)}</button>`).join('');
  const mb = $('#mapBtn'); if(mb) mb.style.display = window.innerWidth<=1080 ? 'inline-flex':'none';
}

/* ---------- DETAIL PAGE ---------- */
function shotsFor(p){ if(hasPhoto(p)) return p.shots.slice(); const s=p.shots.slice(); const extra=[['interior',p.id+20,'golden'],['interior',p.id+30,'day'],[p.shots[0][0],p.id+40,'dusk']]; let i=0; while(s.length<5) s.push(extra[i++]); return s; }
function detail(id){
  const p = P.find(x=>x.id===+id); if(!p) return `<div class="page wrap" style="padding:160px 0"><h1>Property not found</h1><a class="btn btn-primary" href="#/search?p=rent">Back to search</a></div>`;
  state.purpose = p.purpose; const shots = shotsFor(p); state.gallery = shots;
  const monthly = p.purpose==='rent'; const per12 = monthly ? Math.round(p.price*12/Math.max(p.cheques,1)) : 0;
  const near = p.sea ? [['Beach',3],['Supermarket',5],['Mosque',2],['Schools',8],['Mall',12]] : [['Supermarket',4],['Mosque',2],['Schools',6],['Mall',10],['Beach',15]];
  const similar = P.filter(x=>x.id!==p.id && x.purpose===p.purpose && (x.type===p.type||x.wil===p.wil)).slice(0,4);
  const saved = state.saved.has(p.id);
  return `<div class="page"><div class="wrap dgrid">
  <div>
    <nav aria-label="Breadcrumb" class="muted" style="font-size:14px;display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px"><a href="#/search?p=${p.purpose}">${p.purpose==='sale'?'Buy':'Rent'}</a><span>/</span><a href="#/search?p=${p.purpose}&a=${encodeURIComponent(p.wil)}">${esc(p.wil)}</a><span>/</span><span>${esc(p.area)}</span></nav>
    <div class="gallery reveal ${shots.length<3?'one':''}">${shots.slice(0,3).map((s,i)=>`<div class="g" data-lb="${i}" role="button" tabindex="0" aria-label="Open photo ${i+1}">${shot(s)}${(i===2||shots.length<3&&i===0)?`<span class="pill pill-glass more">${ic.eye(14)} ${shots.length<3?'View photo':'All '+shots.length+' photos'}</span>`:''}</div>`).join('')}</div>
    <div class="reveal" style="margin-top:28px"><div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">${p.agent?`<span class="pill pill-ai"><span class="dot"></span>Managed by the AI agent</span>`:''}<span class="pill pill-red">${ic.shield(14)} Verified landlord</span></div>
      <h1 style="margin:0;font-size:clamp(30px,3.4vw,44px);line-height:1.08;letter-spacing:-.035em;font-weight:600">${esc(p.title)}</h1>
      <div class="pc-loc" style="margin-top:10px;font-size:15px">${ic.pin(16)} ${esc(p.area)}, ${esc(p.wil)}, Muscat</div>
      <div class="dhead"><div><span style="font-size:36px;font-weight:600;letter-spacing:-.03em">${money(p)}</span> <span class="muted" style="font-size:15px">${monthly?'a month, 12-month lease':'freehold, ready to transfer'}</span></div>
      <button class="btn btn-ghost btn-sm" data-save="${p.id}">${saved?ic.heartF(16):ic.heart(16)} ${saved?'Saved':'Save'}</button></div>
    </div>
    <div class="facts reveal">${p.beds?`<div class="fact"><b>${p.beds}</b><span>Bedrooms</span></div><div class="fact"><b>${p.baths}</b><span>Bathrooms</span></div>`:`<div class="fact"><b>${typeName(p.type)}</b><span>Type</span></div><div class="fact"><b>${p.park?'Yes':'No'}</b><span>Parking</span></div>`}<div class="fact"><b>${fmt(p.sqm)}</b><span>Square metres</span></div><div class="fact"><b>${esc(p.avail)}</b><span>Available</span></div></div>
    <div class="blk reveal"><h3>About this ${typeName(p.type).toLowerCase()}</h3><p class="muted" style="font-size:16.5px;margin:0">${about(p)}</p></div>
    ${monthly?`<div class="blk reveal"><h3>How you'd pay</h3><p class="muted" style="margin:0">${p.cheques} post-dated cheques over 12 months, plus a one-month deposit. The agent registers the lease with the municipality for you.</p>
      <div class="cheques">${Array.from({length:Math.min(p.cheques,6)},(_,i)=>`<div class="cheq"><b>OMR ${fmt(per12)}</b><span>Cheque ${i+1}</span></div>`).join('')}${p.cheques>6?`<div class="cheq"><b>+${p.cheques-6}</b><span>more</span></div>`:''}</div></div>`:
     `<div class="blk reveal"><h3>The numbers</h3><div class="facts" style="margin-top:0"><div class="fact"><b>OMR ${fmt(Math.round(p.price/p.sqm))}</b><span>Per sqm</span></div><div class="fact"><b>Freehold</b><span>Title</span></div><div class="fact"><b>${p.type==='bldg'?'12 units':'Yes'}</b><span>${p.type==='bldg'?'Fully let':'Residency eligible'}</span></div><div class="fact"><b>AI agent</b><span>Can manage it after you buy</span></div></div></div>`}
    <div class="blk reveal" data-bars><h3>What's nearby</h3><div class="near">${near.map(([n,m])=>`<div class="near-row"><span>${n}</span><span class="bar"><i style="--w:${Math.max(.12,1-m/16)}"></i></span><span class="muted">${m} min</span></div>`).join('')}</div></div>
    ${similar.length?`<div class="blk"><h3>Similar ${p.purpose==='sale'?'properties':'homes'}</h3><div class="rail" style="grid-auto-columns:min(280px,80vw)">${similar.map(x=>card(x)).join('')}</div></div>`:''}
  </div>
  <aside class="agent reveal" style="--d:.1s" data-agent="${p.id}" id="agentBox">${agentPanel(p,'ask')}</aside>
  </div>
  <div class="mbar"><div><b>${money(p)}</b><span>${monthly?'a month':'freehold'}</span></div><div style="display:flex;gap:8px"><button class="btn btn-ghost btn-sm" data-act="toagent" data-to="ask">${ic.chat(16)} Ask</button><button class="btn btn-primary btn-sm" data-act="toagent" data-to="view">Book a viewing</button></div></div></div>`;
}
function about(p){
  const t = typeName(p.type).toLowerCase();
  if(p.type==='office') return `A bright open-plan office floor in ${p.area} with meeting rooms, a pantry and reserved parking. Close to the main highway with easy access across Muscat.`;
  if(p.type==='shop') return `A corner unit with a wide glass front on one of ${p.area}'s busiest streets. Suits retail, a café or a service business. Signage space above the window.`;
  if(p.type==='ware') return `A clear-span warehouse with a loading bay, office cabin and three-phase power in ${p.area}'s industrial area. Trucks can turn on site.`;
  if(p.type==='bldg') return `A well-kept residential building in ${p.area} with 12 flats, all currently let on registered leases. Rent roll, cheque schedule and maintenance history are available on Mumtalikati.`;
  if(p.type==='villa'||p.type==='townhouse') return `A ${p.furn?'fully furnished':'well-kept'} ${p.beds}-bedroom ${t} in ${p.area} with ${p.id===12?'a private pool facing the water':p.type==='villa'?'a private garden':'a roof terrace'} and covered parking. The main bedroom has its own bathroom, and there is a separate majlis for guests.`;
  return `A ${p.furn?'fully furnished':'well-kept'} ${p.beds}-bedroom ${t} in ${p.area}${p.sea?', a short walk from the sea':''}. ${p.beds>1?'The main bedroom has its own bathroom, and '+(p.beds===2?'both':'all the')+' bedrooms have built-in wardrobes. ':''}${p.park?'Covered parking, a lift and a watchman on site.':'Close to shops, buses and the corniche.'}`;
}
function agentPanel(p, tab){
  const head = `<div style="display:flex;gap:12px;align-items:center"><span class="ai-badge" style="width:46px;height:46px;border-radius:14px;font-size:15px">AI</span><div><b>${p.agent?'Mumtalikati agent':esc(p.landlord)}</b><div class="muted" style="font-size:13px">${p.agent?'On behalf of '+esc(p.landlord)+' · usually replies in 2 min':'Verified landlord'}</div></div></div>`;
  const tabs = `<div class="tabs" role="tablist">${[['ask','Ask'],['view','Viewing'],['offer',p.purpose==='sale'?'Offer':'Make an offer']].map(([k,l])=>`<button role="tab" aria-selected="${tab===k}" class="${tab===k?'on':''}" data-tab="${k}">${l}</button>`).join('')}</div>`;
  let body='';
  if(tab==='ask'){
    body = `<div class="chat" id="chat"><div class="msg a">Hi, I'm the AI agent for this ${typeName(p.type).toLowerCase()}. Ask me anything about it, in Arabic or English.</div></div>
    <div class="qchips">${(p.beds?['Is parking included?','How do I pay?','When can I move in?','Is the rent negotiable?']:['Is parking included?','How do I pay?','When is it available?','Can I see it this week?']).map(q=>`<button data-q="${esc(q)}">${q}</button>`).join('')}</div>
    <form class="chat-in" data-form="chat"><label class="sr" for="chatq">Message the agent</label><input id="chatq" name="m" placeholder="Type a question" autocomplete="off"><button class="send" aria-label="Send">${ic.send(16)}</button></form>`;
  } else if(tab==='view'){
    const days=[]; const d0=new Date(); for(let i=1;i<=5;i++){ const d=new Date(d0); d.setDate(d0.getDate()+i); days.push(d); }
    body = `<div data-view><span class="muted" style="font-size:14px">Pick a day</span><div class="days" style="margin-top:8px">${days.map((d,i)=>`<button class="day ${i===0?'on':''}" data-day="${i}"><span>${d.toLocaleDateString('en-GB',{weekday:'short'})}</span><b>${d.getDate()}</b></button>`).join('')}</div>
    <span class="muted" style="font-size:14px;display:block;margin-top:14px">Pick a time</span><div class="slots" style="margin-top:8px">${['10:00 am','5:00 pm','7:30 pm'].map((t,i)=>`<button class="slot ${i===1?'on':''}" data-slot="${i}">${t}</button>`).join('')}</div>
    <button class="btn btn-primary" style="width:100%;margin-top:16px" data-act="bookview">${ic.cal(16)} Confirm viewing</button></div>`;
  } else {
    const lo = p.purpose==='sale'? Math.round(p.price*.85/1000)*1000 : Math.round(p.price*.85/5)*5, hi = p.purpose==='sale'? p.price : Math.round(p.price*1.03/5)*5, st = p.purpose==='sale'?1000:5;
    const start = p.purpose==='sale'? Math.round(p.price*.94/1000)*1000 : Math.round(p.price*.95/5)*5;
    body = p.agent ? `<div data-offer><span class="muted" style="font-size:14px">Your offer ${p.purpose==='sale'?'':'per month'}</span>
      <div class="big-num" style="margin:8px 0 12px">OMR <span id="offerVal">${fmt(start)}</span></div>
      <input type="range" class="range" min="${lo}" max="${hi}" step="${st}" value="${start}" data-range="offer" aria-label="Offer amount">
      <div style="display:flex;justify-content:space-between;font-size:12.5px" class="muted"><span>OMR ${fmt(lo)}</span><span>Asking OMR ${fmt(p.price)}</span></div>
      <button class="btn btn-primary" style="width:100%;margin-top:16px" data-act="sendoffer">${ic.send(16)} Send offer to the agent</button><div id="offerRes"></div></div>`
      : `<p class="muted" style="margin:0">This landlord negotiates directly. Send your offer on WhatsApp and they'll reply there.</p><button class="btn btn-primary" data-act="wa">${ic.wa(16)} Message on WhatsApp</button>`;
  }
  return head + tabs + `<div style="display:flex;flex-direction:column;gap:12px">${body}</div>
   <div style="display:flex;gap:8px;border-top:1px solid var(--line);padding-top:14px"><button class="btn btn-ghost btn-sm" style="flex:1" data-act="wa">${ic.wa(16)} WhatsApp</button><button class="btn btn-ghost btn-sm" style="flex:1" data-act="call">${ic.phone(16)} Call</button></div>
   <span class="muted" style="font-size:12.5px">${p.agent?'The agent answers from the owner\'s rules. The owner approves every lease.':'Contact details are shared only with signed-in users.'}</span>`;
}
function answer(p,q){
  const s=q.toLowerCase(); const per12=Math.round(p.price*12/Math.max(p.cheques,1));
  if(/park|car|garage/.test(s)) return p.park?'Yes, one covered parking space comes with it, and there is visitor parking at the front.':'There is no dedicated parking, but street parking is usually easy nearby.';
  if(/pay|cheque|check|instal|deposit/.test(s)) return p.purpose==='sale'?'Payment is by bank transfer at transfer of title. I can introduce you to partner banks for financing.':`Rent is OMR ${fmt(p.price)} a month, paid with ${p.cheques} post-dated cheques of OMR ${fmt(per12)} each, plus a one-month deposit.`;
  if(/move|avail|when|free|ready/.test(s)) return p.avail==='Now'||p.avail==='Ready'?'It is available now. You could move in within a few days of signing.':`It is available from ${p.avail}. I can hold it for you once the lease is agreed.`;
  if(/negotia|discount|lower|best price|offer|cheaper/.test(s)) return 'The owner has given me some flexibility for a 12-month lease. Use the Make an offer tab and I will answer straight away.';
  if(/pet|cat|dog/.test(s)) return 'The owner prefers no pets, but small pets may be considered. Shall I ask on your behalf?';
  if(/furnish/.test(s)) return p.furn?'Yes, it is fully furnished, including kitchen appliances and bedroom furniture.':'It is unfurnished, with built-in wardrobes and kitchen cabinets.';
  if(/view|visit|see|week/.test(s)) return 'Of course. Open the Viewing tab, pick a time, and I will confirm it with the building watchman.';
  if(/electric|water|bill|utilit/.test(s)) return 'Electricity and water are paid by the tenant through the unit\'s own meters.';
  if(/beach|sea|school|mall|near/.test(s)) return p.sea?'The beach is about 3 minutes on foot. Schools and a mall are within a 10-minute drive.':'Supermarkets and a mosque are a few minutes away, with schools and a mall within about 10 minutes.';
  if(/[\u0600-\u06FF]/.test(q)) return 'أهلاً بك! الإيجار '+fmt(p.price)+' ريال عماني شهرياً. هل تود حجز موعد للمعاينة؟';
  return 'Good question. I will check with the owner and reply here and on WhatsApp within the hour.';
}
/* ---------- OWNERS (AI PMS SALES PAGE) ---------- */
const STEPS = [
 ['List','Writes and prices the listing'],['Screen','Checks ID, salary and references'],['Negotiate','Agrees terms inside your limits'],['Contract','Prepares and registers the lease'],['Collect','Tracks every cheque and payment'],['Maintain','Books rated providers'],['Settle and re-let','Pays every owner, relists early']
];
function stageHtml(i){
  const box = (inner)=>`<div class="stage-in">${inner}</div>`;
  if(i===0) return box(`<div class="two" style="gap:22px"><div class="pcard" style="background:var(--bg);pointer-events:none">${'<div class="pc-media">'+shot(['photo','khuwair'])+'</div>'}<div class="pc-body"><div class="pc-price">OMR 395<small> / month</small></div><div class="pc-title">Bright 2-bed in a brand-new building</div><div class="pc-loc">${ic.pin(14)} Al Khuwair 33, Bousher</div></div></div>
   <div><span class="pill pill-ai"><span class="dot"></span>Written by the agent</span><p style="font-size:15px;margin:14px 0" class="typed" data-type="A bright 2-bedroom flat on the 4th floor of a new building in Al Khuwair 33. Covered parking, lift, and five minutes to the highway."></p>
   <div style="border-radius:16px;background:var(--tint);padding:14px;font-size:14px"><b style="color:var(--red)">Suggested rent: OMR 395</b><br><span class="muted">Based on recent lets of similar 2-bed flats nearby.</span></div></div></div>`);
  if(i===1) return box(`<h4 style="margin:0 0 16px;font-size:20px">Applicants for Flat 2A</h4>${[['Ahmed S.','Engineer, PDO','ID, salary letter, reference',96],['Fatma K.','Teacher, Ministry of Education','ID, salary letter',91],['Rahul M.','Accountant','ID only, salary letter requested',72]].map(a=>`<div class="event" style="margin-bottom:10px"><div><b>${a[0]}</b><div class="muted" style="font-size:13.5px">${a[1]} · ${a[2]}</div></div><span class="verdict ${a[3]>80?'auto':'ask'}">${a[3]>80?'Shortlisted':'Waiting for documents'}</span></div>`).join('')}`);
  if(i===2) return box(`<div style="display:flex;flex-direction:column;gap:10px;max-width:520px"><div class="msg u" style="align-self:flex-start;border-radius:18px 18px 18px 6px">Can you do OMR 370 for Flat 3B?</div><div class="msg a" style="align-self:flex-end;border-radius:18px 18px 6px 18px;background:var(--tint)">The owner can do OMR 395 for 12 months with 4 cheques. That includes covered parking.</div><div class="msg u" style="align-self:flex-start;border-radius:18px 18px 18px 6px">OK, 390 and we sign this week?</div><div class="msg a" style="align-self:flex-end;border-radius:18px 18px 6px 18px;background:var(--tint)">Agreed at OMR 390. I'll send the lease for the owner's approval today.</div><span class="pill pill-ai" style="align-self:center;margin-top:6px">${ic.shield(14)} Inside your rule: accept OMR 390 or more</span></div>`);
  if(i===3) return box(`<div style="max-width:460px;margin:0 auto;border-radius:20px;border:1px solid var(--line);padding:24px;background:var(--bg)"><div style="display:flex;justify-content:space-between"><b>Tenancy agreement</b><span class="muted" style="font-size:13px">Flat 3B</span></div>${[['Tenant','Ahmed S.'],['Rent','OMR 390 a month'],['Term','12 months from 1 Nov'],['Payment','4 post-dated cheques'],['Deposit','OMR 390']].map(r=>`<div style="display:flex;justify-content:space-between;padding:10px 0;border-top:1px solid var(--line);font-size:14px"><span class="muted">${r[0]}</span><b>${r[1]}</b></div>`).join('')}<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap"><span class="pill pill-red">${ic.check(14)} Approved by owner</span><span class="pill pill-ai">${ic.doc(14)} Filed for municipality registration</span></div></div>`);
  if(i===4) return box(`<h4 style="margin:0 0 16px;font-size:20px">Cheques for Flat 3B</h4><div class="grid4">${[['1 Nov','Cleared','auto'],['1 Feb','Due, reminder set','ask'],['1 May','Held','auto'],['1 Aug','Held','auto']].map(c=>`<div class="cheq"><b>OMR 1,170</b><span>${c[0]}</span><div style="margin-top:8px"><span class="verdict ${c[2]}" style="font-size:12px;padding:5px 9px">${c[1]}</span></div></div>`).join('')}</div><div class="event" style="margin-top:16px"><div><b>If a cheque bounces</b><div class="muted" style="font-size:13.5px">The agent contacts the tenant the same day, offers a payment plan inside your rules, and prepares the documents if it goes further.</div></div></div>`);
  if(i===5) return box(`<div class="event"><div><b>AC not cooling, Flat 4B</b><div class="muted" style="font-size:13.5px">Reported by tenant at 10:12 with a photo</div></div><span class="verdict ask">New</span></div><div class="grid3" style="margin:12px 0">${[['CoolTech','4.8',18],['Al Bahja AC','4.5',22],['Rapid Fix','4.1',15]].map((q,j)=>`<div class="fact" style="${j===0?'border-color:var(--red);background:var(--tint)':''}"><b>OMR ${q[2]}</b><span>${q[0]} · ${q[1]} rating</span></div>`).join('')}</div><div class="event"><div><b>Booked CoolTech for 4 pm</b><div class="muted" style="font-size:13.5px">Within your OMR 50 limit. Tenant notified. Invoice will be added to October's statement.</div></div><span class="verdict auto">Handled</span></div>`);
  return box(`<div class="two" style="gap:22px"><div><span class="muted" style="font-size:14px">September, net after repairs and fees</span><div class="big-num" style="margin:8px 0 14px">OMR 4,812</div><div style="display:flex;height:12px;border-radius:12px;overflow:hidden;gap:3px"><i style="flex:40;background:#7E151B"></i><i style="flex:25;background:#B4232A"></i><i style="flex:20;background:#E2462C"></i><i style="flex:15;background:#F7941D"></i></div>${[['Salim','40%','1,925'],['Muna','25%','1,203'],['Khalid','20%','962'],['Aisha','15%','722']].map(s=>`<div style="display:flex;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--line);font-size:14px"><span>${s[0]}, ${s[1]}</span><b>OMR ${s[2]}</b></div>`).join('')}</div>
  <div class="event" style="flex-direction:column;align-items:flex-start"><span class="pill pill-ai"><span class="dot"></span>Re-letting</span><b>Flat 2A lease ends in 58 days</b><span class="muted" style="font-size:14px">Renewal offer sent to the tenant. Listing goes live if they decline, so there is no empty month.</span></div></div>`);
}
function owners(){
  return `<div class="page">
  <section class="night o-hero">
    <div class="orb" style="width:640px;height:640px;background:#B4232A;top:-240px;right:-180px;opacity:.45"></div><div class="orb" style="width:420px;height:420px;background:#F7941D;bottom:-200px;left:-140px;opacity:.25;animation-delay:-8s"></div>
    <div class="wrap o-grid">
      <div>
        <span class="pill reveal" style="background:rgba(247,148,29,.16);color:#FFB27A"><span class="dot"></span>AI property management</span>
        <p class="ar reveal" dir="rtl" style="--d:.05s;margin:22px 0 0;color:#FF9A6B;font-size:18px;text-align:left">وكيلك الذكي لإدارة عقاراتك، وأنت صاحب القرار</p>
        <h1 class="reveal" style="--d:.1s">Meet the AI agent that <span class="serif grad-text">runs your property.</span></h1>
        <p class="lead reveal" style="--d:.16s">It collects rent and tracks every cheque, handles tenants, books repairs, renews leases and settles income with each shareholder. When a unit does come free, it finds the next tenant too. It acts inside your rules and asks you about everything else.</p>
        <div class="reveal" style="--d:.22s;display:flex;gap:12px;flex-wrap:wrap;margin-top:34px"><button class="btn btn-primary" data-act="onboard">Hand over a property ${ic.arrow(16)}</button><a class="btn btn-outline-light" href="#/owners?s=cycle">See how it works</a></div>
        <p class="reveal" style="--d:.28s;margin-top:22px;font-size:14px;color:var(--night-muted)">2 months free · Arabic and English · Web, iPhone and Android</p>
      </div>
      <div class="reveal" style="--d:.15s">${consoleMarkup()}</div>
    </div>
  </section>

  <section class="section wrap" id="cycle">
    <div class="reveal"><span class="eyebrow">The full cycle</span><h2 class="h2">From an empty flat to money in your account. <span class="serif grad-text">And round again.</span></h2></div>
    <div class="cycle"><div class="steps" role="tablist">${STEPS.map((s,i)=>`<button class="step ${i===0?'on':''}" data-step="${i}" role="tab"><span class="n">${i+1}</span><span><b>${s[0]}</b><small>${s[1]}</small></span><span class="prog"></span></button>`).join('')}</div>
    <div class="stage reveal" id="stage">${stageHtml(0)}</div></div>
  </section>

  <section class="section" style="padding-top:0"><div class="wrap">
    <div class="reveal"><span class="eyebrow">Built for Oman</span><h2 class="h2">Made for the way Oman actually rents.</h2></div>
    <div class="bento">
      <div class="bcard c3 reveal"><span class="ico">${ic.cheque(22)}</span><h4>Post-dated cheques, handled</h4><p>Every cheque is logged with its date. The agent reminds you to deposit on time and starts follow-up the day one bounces. Your tenants keep paying the way they're used to.</p></div>
      <div class="bcard c3 reveal" style="--d:.06s"><span class="ico">${ic.doc(22)}</span><h4>Leases registered properly</h4><p>The agent prepares the municipality contract and handles registration and renewal, so your lease protects you if there's ever a dispute.</p></div>
      <div class="bcard c2 dark reveal"><span class="ico">${ic.chart(22)}</span><h4>Ready for the 2028 income tax</h4><p>From 2028 rental income counts toward Oman's personal income tax for high earners. Every rial is already recorded for your accountant.</p></div>
      <div class="bcard c2 reveal" style="--d:.06s"><span class="ico">${ic.users(22)}</span><h4>One building, many owners</h4><p>Income is reconciled and split by share. Every family member sees the same live numbers.</p></div>
      <div class="bcard c2 reveal" style="--d:.12s"><span class="ico">${ic.globe(22)}</span><h4>Arabic and English, any hour</h4><p>Tenants get answers at midnight. You get a summary in the morning.</p></div>
      <div class="bcard c3 reveal"><span class="ico">${ic.shield(22)}</span><h4>Staff access with approvals</h4><p>Give your team view-only access, or let them prepare records that you approve before they count.</p></div>
      <div class="bcard c3 reveal" style="--d:.06s"><span class="ico">${ic.wrench(22)}</span><h4>Rated service providers on call</h4><p>Viewings, inspections and repairs need people. The agent books, tracks and pays rated local providers for you.</p></div>
    </div>
  </div></section>

  ${ownersWhyNow()}

  <section class="night section"><div class="wrap">
    <div class="reveal"><span class="eyebrow">You stay in charge</span><h2 class="h2">Set the rules. <span class="serif grad-text">Watch it decide.</span></h2><p class="lead">Move the limits and see which of today's events the agent handles on its own and which ones it brings to you.</p></div>
    <div class="rules">
      <div class="reveal" style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:28px;padding:26px 28px">
        <div class="rule-row" style="border-top:none"><div class="top"><span>Approve repairs on my behalf up to</span><span class="val" id="vRepair">OMR 50</span></div><input type="range" class="range" min="0" max="200" step="5" value="50" data-rule="repair" aria-label="Repair limit"></div>
        <div class="rule-row" style="border-color:rgba(255,255,255,.08)"><div class="top"><span>Accept rent offers at or above</span><span class="val" id="vRent">OMR 390</span></div><input type="range" class="range" min="350" max="420" step="5" value="390" data-rule="rent" aria-label="Minimum rent"></div>
        <div class="rule-row" style="border-color:rgba(255,255,255,.08)"><div class="top"><span>Relist units before lease end</span><span class="val" id="vRelist">60 days</span></div><input type="range" class="range" min="15" max="90" step="5" value="60" data-rule="relist" aria-label="Relist days"></div>
        <div class="rule-row" style="border-color:rgba(255,255,255,.08)"><div class="top"><span>Ask me before signing any lease</span><button class="toggle on" data-rule-tog="lease" style="background:transparent;border-color:rgba(255,255,255,.2);color:inherit"><span class="sw"></span></button></div></div>
      </div>
      <div class="reveal" style="--d:.08s;display:flex;flex-direction:column;gap:10px;color:var(--ink)" id="events"></div>
    </div>
  </div></section>

  <section class="section wrap" id="calc">
    <div class="reveal"><span class="eyebrow">Management calculator</span><h2 class="h2">What does managing it all cost you?</h2><p class="lead">Rent, cheques, tenants, repairs, renewals and family shares. See what you save when the AI agent runs it, compared with a typical property manager or your own evenings.</p></div>
    <div class="calc">
      <div class="panel light reveal" style="min-height:auto">
        ${[['total','Units you own',1,200,1,20,''],['rent','Average monthly rent per unit',100,1500,10,300,'OMR '],['hours','Hours a week you spend managing',1,40,1,6,'']].map(c=>`<div class="rule-row" style="${c[0]==='total'?'border-top:none':''}"><div class="top"><span>${c[1]}</span><span class="val" id="c_${c[0]}">${c[6]}${c[5]}</span></div><input type="range" class="range" min="${c[2]}" max="${c[3]}" step="${c[4]}" value="${c[5]}" data-calc="${c[0]}" aria-label="${c[1]}"></div>`).join('')}
      </div>
      <div class="panel dark reveal" style="--d:.08s;min-height:auto;justify-content:center">
        <div class="orb" style="width:320px;height:320px;background:#E2462C;bottom:-140px;right:-100px;opacity:.4"></div>
        <span style="color:var(--night-muted)">You save each year compared with a typical manager at 10% of rent</span>
        <div style="font-size:clamp(48px,6vw,84px);font-weight:600;letter-spacing:-.04em;line-height:1" class="grad-text" id="lossOut">OMR 6,960</div>
        <p style="margin:6px 0 0;color:var(--night-muted)" id="feeOut"></p>
        <button class="btn btn-light" style="align-self:flex-start;margin-top:14px" data-act="onboard">Let the agent manage it ${ic.arrow(16)}</button>
      </div>
    </div>
  </section>

  <section class="section wrap" style="padding-top:0">
    <div class="reveal"><span class="eyebrow">Compare</span><h2 class="h2">Keep the fee. Gain the visibility.</h2></div>
    <div class="reveal cmp-wrap" style="overflow-x:auto;margin-top:40px;border-radius:24px;border:1px solid var(--line);background:var(--surface)"><table class="cmp"><thead><tr><th></th><th>Typical property manager</th><th>Spreadsheets and WhatsApp</th><th class="us">Mumtalikati AI agent</th></tr></thead><tbody>
      ${[['Cost','Often 8 to 12% of rent','Your evenings','From RO 0.500 per unit a month'],['Replies to tenants','Office hours','When you can','Any hour, Arabic and English'],['Post-dated cheques','Tracked by staff','In a notebook','Logged, reminded, followed up'],['Lease registration','Usually','A trip to the Sanad office','Prepared and filed'],['Family shareholders','Monthly statement','Long phone calls','Live split for each owner'],['What you can see','A summary','Scattered chats','Every action, logged']].map(r=>`<tr><th scope="row">${r[0]}</th><td class="muted" data-label="Property manager">${r[1]}</td><td class="muted" data-label="Spreadsheets">${r[2]}</td><td class="us yes" data-label="Mumtalikati">${r[3]}</td></tr>`).join('')}
    </tbody></table></div>
  </section>

  <section class="section" id="pricing" style="background:var(--surface-2)"><div class="wrap">
    <div class="reveal" style="display:flex;justify-content:space-between;align-items:flex-end;gap:20px;flex-wrap:wrap"><div><span class="eyebrow">Pricing</span><h2 class="h2">Pay per unit. Start free.</h2><p class="lead">2 months free on every plan. Cancel any time.</p></div>
      <div class="seg" role="group" aria-label="Billing period"><button class="on" data-bill="m">Monthly</button><button data-bill="y">Yearly, save 19%</button></div></div>
    <div class="plans">
      ${[['Basic',1,'Up to 20 rentable units',['Listings, tenants and rent tracking','Web and mobile app','Value-added services on demand']],['Extended',.75,'Up to 100 rentable units',['Everything in Basic','Staff access with approvals','Shareholder settlements']],['Premium',.5,'Up to 1,000 rentable units',['Everything in Extended','Post to OpenSooq, Bayut and more in one click','Portfolio reporting','Priority support']]].map((p,i)=>`<div class="plan reveal" style="--d:${i*.06}s"><b style="font-size:18px">${p[0]}</b><div class="price">RO <span data-price="${p[1]}">${p[1].toFixed(3)}</span><small> per unit a month</small></div><span class="muted" style="font-size:14px">${p[2]}</span><ul>${p[3].map(f=>`<li>${ic.check(15)}${f}</li>`).join('')}</ul><button class="btn btn-ghost" style="margin-top:auto" data-act="onboard">Start free</button></div>`).join('')}
      <div class="plan hot reveal" style="--d:.18s"><b style="font-size:18px;display:flex;gap:8px;align-items:center"><span class="dot"></span>AI Agent, fully managed</b><div class="price" style="font-size:30px">Talk to us</div><span style="font-size:14px;color:var(--night-muted)">The agent runs it end to end</span><ul>${['Letting, screening and negotiation','Cheques, recoveries and registration','Repairs with rated providers','Settlements and re-letting'].map(f=>`<li>${ic.check(15)}${f}</li>`).join('')}</ul><button class="btn btn-primary" style="margin-top:auto" data-act="onboard">Book a call</button></div>
    </div>
  </div></section>

  <section class="section wrap" id="faq">
    <div class="reveal" style="text-align:center"><span class="eyebrow">Questions</span><h2 class="h2">What owners ask us first</h2></div>
    <div class="faq">${[['Can the AI agent really negotiate for me?','Yes, within the limits you set, such as the lowest rent you will accept. Anything outside your rules comes to you with a recommendation, and you approve every lease before it is signed.'],['Do my tenants have to stop paying by cheque?','No. Post-dated cheques work as they do today. The agent logs each one, reminds you to deposit it, and follows up if one bounces. Tenants can also pay in the app if they prefer.'],['What happens if a tenant stops paying?','The agent sends reminders on the schedule you choose, offers a payment plan if you allow it, and prepares the documents your lawyer needs if the case has to go further.'],['Who does the work that needs a person?','Viewings, inspections and repairs are done by rated local service providers and our onboarding team. The agent books them, tracks the job and records the cost.'],['Who can see my numbers?','Only the people you invite. Family shareholders see their share, and staff see only what their role allows.'],['Can I start with just one building?','Yes. Our team loads your units, tenants and cheques for you, and the first 2 months are free.']].map((q,i)=>`<div class="qa reveal ${i===0?'open':''}"><button data-qa aria-expanded="${i===0}"><span>${q[0]}</span><span class="pm">${ic.plus(16)}</span></button><div class="ans"><div><p>${q[1]}</p></div></div></div>`).join('')}</div>
  </section>

  <section class="section night"><div class="wrap reveal">
    <h2 class="h2" style="max-width:14em">Hand over one building. Judge the agent by its first month.</h2>
    <p class="lead" style="color:#FFE7DE">Our team loads your units, tenants and cheques for you, free. You set the rules. The agent takes it from there.</p>
    <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:32px"><button class="btn btn-light" data-act="onboard">Book free onboarding ${ic.arrow(16)}</button><button class="btn btn-outline-light" data-act="wa">${ic.wa(16)} WhatsApp us</button></div>
  </div></section>
  </div>`;
}
function renderEvents(){
  const r = state.rules; const el=$('#events'); if(!el) return;
  const ev = [
    ['AC repair quote, Flat 4B','OMR 18 from a 4.8-rated technician', 18<=r.repair],
    ['Water heater replacement, Unit 2','OMR 85, best of 3 quotes', 85<=r.repair],
    ['Rent offer for Flat 3B','Tenant offers OMR 380 for 12 months', 380>=r.rent],
    ['Rent offer for Flat 6','Tenant offers OMR 400 for 12 months', 400>=r.rent],
    ['Lease ready for Flat 2A','Terms agreed inside your limits', !r.lease],
    ['Flat 5A lease ends in 58 days','Tenant has not confirmed renewal', 58<=r.relist, 'Relisting now','Waits for now']
  ];
  el.innerHTML = ev.map(e=>`<div class="event"><div><b style="font-size:15px">${e[0]}</b><div class="muted" style="font-size:13.5px">${e[1]}</div></div><span class="verdict ${e[2]?'auto':'ask'}">${e[2]?(e[3]||'Agent handles it'):(e[4]||'Asks you first')}</span></div>`).join('');
}
function renderCalc(){
  const c = state.calc; const rate = c.total<=20?1:c.total<=100?.75:.5; const fee = Math.round(c.total*rate*12); const loss = Math.max(0, Math.round(c.total*c.rent*12*.10) - fee); const hrs = Math.round(c.hours*52*.8);
  const out=$('#lossOut'); if(!out) return;
  const from = out._v||0; const t0=performance.now(); out._v=loss; cancelAnimationFrame(out._raf);
  const tick=(t)=>{ const k=Math.min(1,(t-t0)/600); const v=Math.round(from+(loss-from)*(1-Math.pow(1-k,3))); out.textContent='OMR '+fmt(v); if(k<1) out._raf=requestAnimationFrame(tick); }; out._raf=requestAnimationFrame(tick);
  $('#feeOut').innerHTML = `Or, if you manage it yourself, about <b style="color:var(--night-ink)">${fmt(hrs)} hours a year back</b>, assuming the agent takes 80% of the cheque chasing, tenant messages and repair calls off your hands. Mumtalikati for all ${c.total} unit${c.total>1?'s':''} costs about OMR ${fmt(fee)} a year on the ${c.total<=20?'Basic':c.total<=100?'Extended':'Premium'} plan.`;
  ['hours','total'].forEach(k=>$('#c_'+k).textContent=c[k]); $('#c_rent').textContent='OMR '+fmt(c.rent);
}

/* ---------- LIST YOUR PROPERTY (AI WIZARD) ---------- */
const PORTALS=[['opensooq','OpenSooq','#2B6CB0','Classifieds site in Oman'],['bayut','Bayut Oman','#1F8A5B','Property portal for Oman'],['dubizzle','Dubizzle','#C0392B','Classifieds across the Gulf'],['fb','Facebook Marketplace','#3B5998','Local buyers and tenants']];
function portalUI(){ const L=state.lst; const n=L.portals.length; const note=$('#portalNote'); if(note) note.innerHTML = n? `Mumtalikati plus ${n} more portal${n>1?'s':''}. Posting on other portals needs <b>Premium</b>.` : 'Only Mumtalikati is selected. Publishing is free.'; $$('[data-act="publish"]').forEach(b=>b.innerHTML = n? `Publish to ${n+1} portals ${ic.arrow(16)}` : `Publish free ${ic.arrow(16)}`); }
function listPage(){
  const L = state.lst = {type:'flat',beds:2,area:'Al Khuwair',rent:380,feat:['Parking','Lift'],written:false,portals:[]};
  return `<div class="page"><div class="wrap lgrid">
    <div>
      <span class="pill pill-ai reveal"><span class="dot"></span>AI listing writer</span>
      <h1 class="h2 reveal" style="--d:.05s">List your property in <span class="serif grad-text">60 seconds.</span></h1>
      <p class="lead reveal" style="--d:.1s">Tell us the basics. The AI writes the listing in English and Arabic and checks your price against nearby lets. Listing is free.</p>
      <div class="field reveal"><label>Property type</label><div class="opts">${[['flat','Flat'],['villa','Villa'],['townhouse','Townhouse'],['shop','Shop'],['office','Office']].map(([k,l])=>`<button class="chip ${k==='flat'?'on':''}" data-lt="${k}">${l}</button>`).join('')}</div></div>
      <div class="field reveal" id="bedsField"><label>Bedrooms</label><div class="opts">${[1,2,3,4,5].map(b=>`<button class="chip ${b===2?'on':''}" data-lb2="${b}">${b}</button>`).join('')}</div></div>
      <div class="field reveal"><label for="larea">Area</label><select class="input" id="larea" data-lf="area">${['Al Khuwair','Azaiba','Shatti Al Qurum','Al Mouj','Al Mawaleh','Al Hail','Ghubra','Ruwi','Muttrah'].map(a=>`<option>${a}</option>`).join('')}</select></div>
      <div class="field reveal"><label for="lrent">Monthly rent you'd like (OMR)</label><input class="input" id="lrent" type="number" inputmode="numeric" value="380" data-lf="rent"><span class="muted hint" style="font-size:14px" id="priceHint"></span></div>
      <div class="field reveal"><label>Features</label><div class="opts">${['Parking','Lift','Sea view','Furnished','Pool','Gym','Maid room','Garden'].map(f=>`<button class="chip ${['Parking','Lift'].includes(f)?'on':''}" data-feat="${f}">${f}</button>`).join('')}</div></div>
      <div class="field reveal"><label>Where should it appear?</label>
        <div class="usp">${ic.globe(16)}<span><b>Post once, show everywhere.</b> Your listing on Mumtalikati is free. Tick other Oman portals and we post, update and take down the listing on all of them for you.</span></div>
        <div class="portals">
          <div class="portal locked"><span class="pl" style="background:var(--red)">M</span><span class="pt"><b>Mumtalikati</b><span>Always included</span></span><span class="tag-free">FREE</span><span class="bx">${ic.check(13)}</span></div>
          ${PORTALS.map(([k,n,c,d])=>`<button type="button" class="portal" data-portal="${k}" aria-pressed="false"><span class="pl" style="background:${c}">${n[0]}</span><span class="pt"><b>${n}</b><span>${d}</span></span><span class="tag-prem">${ic.bolt(11)}PREMIUM</span><span class="bx">${ic.check(13)}</span></button>`).join('')}
        </div>
        <span class="muted" style="font-size:13px" id="portalNote">Only Mumtalikati is selected. Publishing is free.</span>
      </div>
      <button class="btn btn-primary reveal" style="margin-top:28px" data-act="aiwrite">${ic.spark(18)} Write my listing with AI</button>
      <div id="aiOut"></div>
    </div>
    <aside style="position:sticky;top:110px;--d:.1s" class="reveal"><span class="muted" style="font-size:14px;display:block;margin-bottom:10px">Live preview</span><div id="lprev"></div>
      <div class="panel light" style="min-height:auto;margin-top:16px;padding:24px"><b>Want it managed too?</b><p class="muted" style="margin:0;font-size:14.5px">Turn on the AI agent and it will answer enquiries, book viewings and negotiate inside your rules.</p><a class="link-arrow" href="#/owners">Meet the AI agent ${ic.arrow(16)}</a></div></aside>
  </div></div>`;
}
const RANGES = {flat:{1:[180,280],2:[300,420],3:[420,560],4:[520,700],5:[600,800]},villa:{1:[350,450],2:[400,550],3:[550,800],4:[650,950],5:[800,1200]},townhouse:{1:[300,400],2:[380,500],3:[480,620],4:[560,750],5:[650,850]},shop:[250,500],office:[500,1100]};
function listPreview(){
  const L=state.lst; const kind = L.type==='villa'||L.type==='townhouse'?'villa':L.type==='shop'?'shop':L.type==='office'?'office':'tower';
  const p = {id:999,purpose:'rent',type:L.type,title:L.title||(L.type==='shop'||L.type==='office'?typeName(L.type)+' in '+L.area:`${L.beds}-bed ${typeName(L.type).toLowerCase()} in ${L.area}`),area:L.area,wil:'Muscat',price:+L.rent||0,beds:(L.type==='shop'||L.type==='office')?0:L.beds,baths:Math.max(1,L.beds),sqm:L.type==='shop'?60:L.type==='office'?220:40+L.beds*45,agent:true,shots:[['upload']]};
  $('#lprev').innerHTML = card(p,{cls:'hl'}).replace('data-open="999"','');
  const rg = (L.type==='shop'||L.type==='office') ? RANGES[L.type] : RANGES[L.type][L.beds];
  const v=+L.rent; const h=$('#priceHint'); if(h) h.innerHTML = `${ic.spark(14)} Similar ${p.beds?p.beds+'-bed ':''}${typeName(L.type).toLowerCase()}s nearby let for OMR ${rg[0]} to ${rg[1]}. ${v<rg[0]?'You could ask for more.':v>rg[1]?'This may take longer to let.':'Your price looks right.'}`;
  const bf=$('#bedsField'); if(bf) bf.style.display=(L.type==='shop'||L.type==='office')?'none':'flex';
}
function typeOut(el,text,speed,done){ let i=0; el.classList.add('caret'); const h=setInterval(()=>{ i+=2; el.textContent=text.slice(0,i); if(i>=text.length){ clearInterval(h); el.classList.remove('caret'); done&&done(); } },speed); state.cleanups.push(()=>clearInterval(h)); }
/* ---------- NEWS ---------- */
const CATS = [['all','All'],['law','Law and regulation'],['tax','Tax'],['market','Market'],['leasing','Leasing'],['owners','Owners']];
const NEWS = [
 {id:1, cat:'tax', date:'30 Jun 2025', key:20250630, stat:'5%', statLabel:'income tax from 2028 on income above OMR 42,000',
  title:"Rental income will count toward Oman's first personal income tax",
  summary:"Oman's Personal Income Tax Law, issued by Royal Decree 56/2025, takes effect on 1 January 2028. Tax residents whose gross annual income is above OMR 42,000 will pay a flat 5%, and rental income is included in what counts. The government expects around 99% of people to stay below the threshold.",
  why:"If you own several buildings, your rent alone can pass the threshold. Mumtalikati records every rial of rent and every expense by property and by shareholder, so your accountant has clean figures when the first returns are due.",
  cta:['owners','Get tax-ready with Mumtalikati'], src:[['WTW','https://www.wtwco.com/en-us/insights/2025/08/oman-personal-income-tax-law'],['Deloitte Middle East','https://www.deloitte.com/middle-east/en/services/tax/perspectives/oman-personal-income-tax-law-issued.html']]},
 {id:2, cat:'law', date:'10 Mar 2026', key:20260310, stat:'RD 79/2025', statLabel:'Real Estate Regulation Law now in force',
  title:"New real estate law puts brokers and marketers under licence",
  summary:"The Real Estate Regulation Law came into force on 10 March 2026, bringing development, brokerage, valuation and jointly owned property under one framework. Anyone brokering or marketing property now needs a licence from the Ministry of Housing and Urban Planning, which has new powers to enforce the rules.",
  why:"Dealing with unlicensed middlemen now carries real risk for owners. Mumtalikati keeps every enquiry, offer and signed agreement on record, so there is always a clear trail of who did what.",
  cta:['owners','See how the AI agent works'], src:[['BSA Law','https://bsalaw.com/insight/real-estate-regulation-law-in-the-sultanate-79-2025-towards-sustainable-real-estate-governance/'],['Mondaq','https://www.mondaq.com/land-law-agriculture/1710962/real-estate-regulation-law-in-the-sultanate-of-oman-792025-towards-sustainable-real-estate-governance']]},
 {id:3, cat:'owners', date:'10 Mar 2026', key:20260309, stat:'Mandatory', statLabel:"owners' associations for shared buildings",
  title:"Every shared building now needs an owners' association",
  summary:"Under the new law, each jointly owned property or multi-unit development must have an owners' association to manage common areas, maintain facilities and represent owners. Associations have their own legal and financial standing and are supervised by the Ministry to make sure accounts are transparent.",
  why:"An association needs service charges collected, maintenance tracked and accounts every owner can trust. Mumtalikati already does this for single owners and family portfolios, and can keep the books for an association too.",
  cta:['onboard','Talk to us about your building'], src:[['Mondaq','https://www.mondaq.com/land-law-agriculture/1710962/real-estate-regulation-law-in-the-sultanate-of-oman-792025-towards-sustainable-real-estate-governance'],['Lexis Middle East','https://www.lexismiddleeast.com/law/Oman/MinisterialDecision_204_2024/en']]},
 {id:4, cat:'law', date:'18 May 2026', key:20260518, stat:'RD 56/2026', statLabel:'new Real Estate Registry Law',
  title:"Oman's new registry law opens the door to digital title deeds",
  summary:"A new Real Estate Registry Law took effect on 18 May 2026, replacing the law from 1998. A mulkiya can now be an electronic document, and the Minister may authorise government and private entities to provide registration services, with executive regulations still to come.",
  why:"Property records are moving online. Mumtalikati keeps your deeds, leases and documents together in one place today, ready to connect as new e-services open up.",
  cta:['owners','Keep every document in one place'], src:[['Dentons','https://www.dentons.com/en/insights/alerts/2026/june/3/new-law-of-the-real-estate-registry-in-oman']]},
 {id:5, cat:'market', date:'15 Sep 2026', key:20260915, stat:'OMR 1.72bn', statLabel:'property traded from January to July 2026',
  title:"Property deals reach OMR 1.72 billion in the first seven months of 2026",
  summary:"Figures from the National Centre for Statistics and Information show OMR 1.716 billion of real estate traded between January and July 2026, 7.7% more than a year earlier. Sales contracts grew fastest, rising 15.7% in value to OMR 843.2 million.",
  why:"More buyers means more new landlords, and many have never let a property before. Mumtalikati's AI agent lets a first-time owner rent out a unit without hiring a property manager.",
  cta:['list','List a property free'], src:[['Arabian Business','https://www.arabianbusiness.com/real-estate/oman-real-estate-transactions-hit-4-5bn-as-property-sales-jump-15-7']]},
 {id:6, cat:'law', date:'25 Jul 2026', key:20260725, stat:'190+', statLabel:'real estate companies registered with the Ministry',
  title:"Ministry tightens developer licensing as the market grows",
  summary:"The Ministry of Housing and Urban Planning says developers must finish licensing and registration before they advertise or sell a project, through a three-stage process. More than 190 real estate companies were registered with the Ministry by the end of June 2026.",
  why:"Knowing who you are dealing with matters more than ever. Owners on Mumtalikati are verified before their listing goes live, so tenants and buyers can see who is behind every property.",
  cta:['search','Browse verified listings'], src:[['The Arabian Stories','https://www.thearabianstories.com/2026/07/25/oman-sets-three-stage-licensing-process-for-real-estate-projects-as-deals-rise-5-4/'],['Oman Observer','https://www.omanobserver.om/article/1193440/business/oman-reinforces-property-market-rules']]},
 {id:7, cat:'leasing', date:'3 Jan 2025', key:20250103, stat:'5 Jan 2025', statLabel:'commercial leases moved to a new platform',
  title:"Commercial lease registration moves to the Oman Business Platform",
  summary:"From 5 January 2025, Muscat Municipality stopped registering, renewing and amending commercial lease contracts on its own e-services portal and moved these services to the Oman Business Platform.",
  why:"Residential and commercial leases now go through different systems. The agent knows which is which and prepares the right paperwork for every shop, office and flat you own.",
  cta:['owners','Let the agent handle registration'], src:[['Times of Oman','https://timesofoman.com/article/153683-muscat-municipality-announces-transition-of-lease-services']]},
 {id:8, cat:'leasing', date:'Sep 2026', key:20260907, stat:'3%', statLabel:'registration fee on the full lease value',
  title:"Registering a lease in Muscat: the 3% fee, and why it protects you",
  summary:"Residential leases in Muscat are registered through the municipality's e-services, the Baladiyati app or Sanad offices. The fee is 3% of the rent for the whole contract period, down from the 5% charged in earlier years.",
  why:"A registered lease is your protection if a dispute ever reaches the authorities. The agent prepares the contract, files it and reminds you before renewal, so no lease slips through.",
  cta:['owners','See the full rental cycle'], src:[['The Oman Hub','https://theomanhub.com/register-lease-contract-muscat/'],['Muscat Municipality','https://www.mm.gov.om/NewNewsDetails.aspx?MID=59&MoID=1&NID=2397']]},
 {id:9, cat:'market', date:'Jan 2026', key:20260102, stat:'10 to 14%', statLabel:'estimated vacancy in older unfurnished flats',
  title:"Muscat rents edge up while older buildings struggle to fill",
  summary:"Market estimates for 2026 put Muscat rent growth at about 2% to 4%. Citywide vacancy is estimated at 7% to 10%, but closer to 3% to 5% for good furnished flats in areas like Al Mouj and Qurum, and 10% to 14% for older unfurnished units in weaker locations.",
  why:"For most landlords, empty months cost more than low rent. The agent relists before a lease ends and answers every enquiry within minutes, so units spend less time empty.",
  cta:['calc','See what managing it costs you'], src:[['Sands of Wealth (market estimates)','https://sandsofwealth.com/blogs/news/muscat-rents']]},
 {id:10, cat:'owners', date:'Aug 2026', key:20260830, stat:'No sponsor', statLabel:'residency for foreign owners in tourism complexes',
  title:"Foreign owners in tourism complexes can hold residency without a sponsor",
  summary:"Recent changes let foreign freehold owners in Integrated Tourism Complexes hold renewable residency without an Omani sponsor, as reported in August 2026. The Ministry of Housing has said the changes cover residency rights only, not where foreigners are allowed to own.",
  why:"Many of these owners live abroad for much of the year. The AI agent lets, collects and reports on their property in English or Arabic, wherever they are.",
  cta:['owners','Manage your property from abroad'], src:[['Irfan Invest','https://www.irfaninvest.com/insights/oman-owner-visa-sponsor-free-2026']]}
];
const catName = k => (CATS.find(c=>c[0]===k)||['',''])[1];
const sortedNews = () => NEWS.slice().sort((a,b)=>b.key-a.key);
function ctaHref(c){ return c[0]==='owners'?'#/owners':c[0]==='calc'?'#/owners?s=calc':c[0]==='list'?'#/list':c[0]==='search'?'#/search?p=rent':'#/owners'; }
function ncard(n, o={}){
  return `<a href="#/news/${n.id}" class="ncard ${o.cls||''} reveal" style="--d:${o.d||0}s">
    <div class="n-top"><span class="pill pill-red">${catName(n.cat)}</span><span class="muted" style="font-size:13px">${n.date}</span></div>
    <div class="n-stat"><b class="grad-text">${n.stat}</b><span>${n.statLabel}</span></div>
    <h3>${esc(n.title)}</h3>
    ${o.long?`<p class="n-sum">${esc(n.summary)}</p>`:''}
    <span class="link-arrow n-go">Read the update ${ic.arrow(16)}</span></a>`;
}
function newsFeature(n){
  return `<a href="#/news/${n.id}" class="nfeat reveal">
    <div class="orb" style="width:420px;height:420px;background:#E2462C;top:-160px;right:-120px;opacity:.4"></div>
    <div class="n-top"><span class="pill" style="background:rgba(247,148,29,.16);color:#FFB27A">Featured · ${catName(n.cat)}</span><span style="font-size:13px;color:var(--night-muted)">${n.date}</span></div>
    <div class="nf-grid"><div class="nf-stat"><b class="grad-text">${n.stat}</b><span>${n.statLabel}</span></div>
    <div><h3>${esc(n.title)}</h3><p>${esc(n.summary)}</p><span class="link-arrow" style="color:#FFB27A">Read what it means for you ${ic.arrow(16)}</span></div></div></a>`;
}
function homeNews(){
  const feat = NEWS.find(n=>n.id===1); const rest = sortedNews().filter(n=>n.id!==1).slice(0,3);
  return `<section class="section wrap" style="padding-top:20px">
    <div class="reveal" style="display:flex;justify-content:space-between;align-items:flex-end;gap:20px;flex-wrap:wrap"><div><span class="eyebrow">News and updates</span><h2 class="h2">Oman's property rules are changing. <span class="serif grad-text">We're ready.</span></h2></div><a href="#/news" class="btn btn-ghost">All news ${ic.arrow(16)}</a></div>
    <div style="margin-top:44px">${newsFeature(feat)}</div>
    <div class="ngrid" style="margin-top:16px">${rest.map((n,i)=>ncard(n,{d:i*.06})).join('')}</div>
  </section>`;
}
function newsPage(qs){
  const cat = qs.get('c')||'all';
  const list = sortedNews().filter(n=>cat==='all'||n.cat===cat);
  const showFeat = cat==='all';
  return `<div class="page"><section class="hero" style="padding-bottom:40px"><div class="orb o1" style="opacity:.35"></div><div class="orb o3"></div><div class="grain"></div><div class="wrap">
    <span class="pill pill-ai reveal"><span class="dot"></span>Updated October 2026</span>
    <p class="hero-ar ar reveal" dir="rtl" style="--d:.05s;margin:22px 0 0;text-align:left">أخبار العقار في عُمان، وما تعنيه لك</p>
    <h1 class="reveal" style="--d:.1s;font-size:clamp(42px,6vw,84px)">Oman property news, and <span class="serif grad-text">what it means for you.</span></h1>
    <p class="hero-sub reveal" style="--d:.16s">New laws, new taxes and fresh market numbers, explained in plain words for owners, tenants and investors.</p>
    <div class="cats reveal" style="--d:.22s;margin-top:30px;gap:8px">${CATS.map(([k,l])=>`<a href="#/news${k==='all'?'':'?c='+k}" class="chip ${cat===k?'on':''}">${l}</a>`).join('')}</div>
  </div></section>
  <section class="wrap" style="padding-bottom:100px">
    ${showFeat?`<div>${newsFeature(NEWS.find(n=>n.id===1))}</div>`:''}
    <div class="ngrid" style="margin-top:16px">${list.filter(n=>!showFeat||n.id!==1).map((n,i)=>ncard(n,{d:(i%3)*.06,long:true})).join('')}</div>
    <p class="muted reveal" style="font-size:13px;margin-top:40px;max-width:52em">Summaries are written by Mumtalikati from the sources linked on each update. They are general information, not legal or tax advice. Please check with a qualified adviser before acting.</p>
  </section></div>`;
}
function newsArticle(id){
  const n = NEWS.find(x=>x.id===+id); if(!n) return `<div class="page wrap" style="padding:160px 0"><h1>Update not found</h1><a class="btn btn-primary" href="#/news">All news</a></div>`;
  const related = sortedNews().filter(x=>x.id!==n.id && (x.cat===n.cat)).concat(sortedNews().filter(x=>x.id!==n.id && x.cat!==n.cat)).slice(0,3);
  const ctaBtn = n.cta[0]==='onboard' ? `<button class="btn btn-light" data-act="onboard">${n.cta[1]} ${ic.arrow(16)}</button>` : `<a class="btn btn-light" href="${ctaHref(n.cta)}">${n.cta[1]} ${ic.arrow(16)}</a>`;
  return `<div class="page"><article class="wrap art" style="padding-top:120px;padding-bottom:40px;max-width:980px">
    <a href="#/news" class="link-arrow reveal" style="font-size:14px">${ic.left(16)} All news</a>
    <div class="reveal" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:24px"><span class="pill pill-red">${catName(n.cat)}</span><span class="muted" style="font-size:14px">${n.date}</span></div>
    <h1 class="reveal" style="--d:.05s;font-size:clamp(34px,4.6vw,60px);line-height:1.04;letter-spacing:-.04em;font-weight:600;margin:18px 0 0">${esc(n.title)}</h1>
    <div class="art-stat reveal" style="--d:.1s"><b class="grad-text">${n.stat}</b><span>${n.statLabel}</span></div>
    <p class="reveal" style="--d:.14s;font-size:clamp(18px,1.5vw,21px);line-height:1.7;margin:30px 0 0">${esc(n.summary)}</p>
    <div class="why reveal">
      <div class="orb" style="width:360px;height:360px;background:#E2462C;bottom:-160px;right:-120px;opacity:.4"></div>
      <span class="pill" style="background:rgba(247,148,29,.16);color:#FFB27A;align-self:flex-start"><span class="dot"></span>What this means for you</span>
      <p style="font-size:clamp(19px,1.7vw,24px);line-height:1.5;margin:0;font-weight:500;letter-spacing:-.01em">${esc(n.why)}</p>
      <div style="display:flex;gap:10px;flex-wrap:wrap">${ctaBtn}<button class="btn btn-outline-light" data-act="wa">${ic.wa(16)} Ask us on WhatsApp</button></div>
    </div>
    <div class="reveal" style="margin-top:34px"><b style="font-size:14px">Sources</b><div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">${n.src.map(s=>`<a class="chip" href="${s[1]}" target="_blank" rel="noopener noreferrer">${esc(s[0])} ${ic.arrow(14)}</a>`).join('')}</div>
    <p class="muted" style="font-size:13px;margin-top:16px">Summary written by Mumtalikati. General information only, not legal or tax advice.</p></div>
  </article>
  <section class="wrap" style="padding:30px 28px 100px"><h2 class="reveal" style="font-size:28px;letter-spacing:-.03em;margin:0 0 20px">More updates</h2><div class="ngrid">${related.map((x,i)=>ncard(x,{d:i*.06})).join('')}</div></section></div>`;
}
function ownersWhyNow(){
  const items=[1,2,3].map(i=>NEWS.find(n=>n.id===i));
  return `<section class="section wrap" style="padding-top:0"><div class="reveal"><span class="eyebrow">Why now</span><h2 class="h2">New laws and a new tax. <span class="serif grad-text">Owners need records.</span></h2><p class="lead">Three changes that make running property on paper and WhatsApp riskier every month.</p></div>
    <div class="ngrid" style="margin-top:44px">${items.map((n,i)=>ncard(n,{d:i*.06,long:true})).join('')}</div>
    <div class="reveal" style="margin-top:22px"><a href="#/news" class="link-arrow">Read all property news ${ic.arrow(16)}</a></div></section>`;
}
/* ---------- MODALS ---------- */
function openLayer(html){ $('#layer').innerHTML = html; document.body.style.overflow='hidden'; const f=$('#layer [data-autofocus]')||$('#layer button'); f&&f.focus(); }
function closeLayer(){ $('#layer').innerHTML=''; document.body.style.overflow=''; }
function onboard(step){
  const o = state.onb = state.onb||{step:0,who:'',units:'',name:'',wa:''}; if(step!=null) o.step=step;
  const prog = `<div class="progress">${[0,1,2].map(i=>`<i class="${i<=o.step?'on':''}"></i>`).join('')}</div>`;
  let body='';
  if(o.step===0) body = `<h2 style="margin:0;font-size:28px;letter-spacing:-.03em">Who owns the property?</h2><p class="muted">So we can set up the right access for you.</p><div class="opts" style="flex-direction:column;align-items:stretch">${['I own it myself','It is family-owned, with shareholders','A company owns it'].map(w=>`<button class="event" style="cursor:pointer;text-align:left" data-onb-who="${w}"><b>${w}</b>${ic.arrow(16)}</button>`).join('')}</div>`;
  if(o.step===1) body = `<h2 style="margin:0;font-size:28px;letter-spacing:-.03em">How many units?</h2><p class="muted">Flats, villas, shops or offices. Roughly is fine.</p><div class="slots" style="grid-template-columns:repeat(2,1fr)">${['1 to 5','6 to 20','21 to 100','More than 100'].map(u=>`<button class="slot" style="padding:18px" data-onb-units="${u}">${u}</button>`).join('')}</div>`;
  if(o.step===2) body = `<h2 style="margin:0;font-size:28px;letter-spacing:-.03em">Where should we reach you?</h2><p class="muted">Our onboarding team will WhatsApp you to book a short call.</p><form data-form="onb" style="display:flex;flex-direction:column;gap:12px"><label class="sr" for="onn">Name</label><input class="input" id="onn" name="n" placeholder="Your name" required data-autofocus><label class="sr" for="onw">WhatsApp number</label><input class="input" id="onw" name="w" placeholder="WhatsApp, e.g. 9xxx xxxx" inputmode="tel" required><button class="btn btn-primary">Book my free onboarding ${ic.arrow(16)}</button></form>`;
  if(o.step===3) body = `<div class="success"><div class="check-anim">${ic.check(30)}</div><h2 style="margin:6px 0 0;font-size:28px;letter-spacing:-.03em">Thanks, ${esc(o.name||'there')}.</h2><p class="muted" style="margin:0">We'll WhatsApp you within one working day to set up your ${esc(o.units||'')} units. The first 2 months are free.</p><p class="muted" style="font-size:12.5px">Prototype: nothing was sent.</p><button class="btn btn-primary" data-act="close">Done</button></div>`;
  openLayer(`<div class="overlay" data-close-bg><div class="modal" role="dialog" aria-modal="true" aria-label="Hand over a property"><button class="icon-btn x" data-act="close" aria-label="Close">${ic.close()}</button>${o.step<3?prog:''}${body}</div></div>`);
}
function lightbox(i){
  const g=state.gallery||[]; state.lb=(i+g.length)%g.length; const s=g[state.lb];
  openLayer(`<div class="lightbox" data-close-bg role="dialog" aria-modal="true" aria-label="Photo viewer"><button class="lb-btn" style="top:20px;right:20px" data-act="close" aria-label="Close">${ic.close(22)}</button><button class="lb-btn" style="left:20px" data-lbgo="-1" aria-label="Previous">${ic.left(22)}</button><div class="lb-img">${shot(s)}</div><button class="lb-btn" style="right:20px" data-lbgo="1" aria-label="Next">${ic.right(22)}</button><span style="position:absolute;bottom:24px;color:#fff;font-size:14px">${state.lb+1} / ${g.length}</span></div>`);
}
function savedDrawer(){
  const items = P.filter(p=>state.saved.has(p.id));
  openLayer(`<div class="overlay" data-close-bg style="place-items:stretch end;padding:0"><div class="drawer" role="dialog" aria-modal="true" aria-label="Saved properties"><div style="display:flex;justify-content:space-between;align-items:center"><h2 style="margin:0;font-size:26px;letter-spacing:-.03em">Saved</h2><button class="icon-btn" data-act="close" aria-label="Close">${ic.close()}</button></div>
  ${items.length? items.map(p=>`<div style="display:grid;grid-template-columns:96px 1fr auto;gap:14px;align-items:center;padding:14px 0;border-bottom:1px solid var(--line)"><a href="#/property/${p.id}" data-act="close" style="border-radius:14px;overflow:hidden;height:72px" class="thumb">${shot(p.shots[0])}</a><a href="#/property/${p.id}" data-act="close"><b style="display:block">${money(p)}</b><span class="muted" style="font-size:13.5px">${esc(p.title)}</span></a><button class="icon-btn" data-save="${p.id}" aria-label="Remove">${ic.close(16)}</button></div>`).join('') : `<div class="empty" style="margin-top:24px;padding:40px 20px"><div style="color:var(--red);display:grid;place-items:center">${ic.heart(30)}</div><p style="font-weight:600;margin:12px 0 4px">Nothing saved yet</p><p class="muted" style="margin:0;font-size:14px">Tap the heart on any property to keep it here.</p></div>`}
  </div></div>`);
}
function mobileMenu(){ openLayer(`<div class="mobile-menu" role="dialog" aria-modal="true" aria-label="Menu"><button class="icon-btn" style="position:absolute;top:calc(env(safe-area-inset-top,0px) + 16px);right:20px" data-act="close" aria-label="Close menu">${ic.close(24)}</button><a href="#/search?p=rent" data-act="close">Rent</a><a href="#/search?p=sale" data-act="close">Buy</a><a href="#/owners" data-act="close">AI agent for owners</a><a href="#/owners?s=pricing" data-act="close">Pricing</a><a href="#/news" data-act="close">News</a><a href="#/list" data-act="close">List a property free</a></div>`); }

/* ---------- ROUTER ---------- */
let io;
function observe(){
  io && io.disconnect();
  io = new IntersectionObserver(es=>es.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } }),{threshold:.12, rootMargin:'0px 0px -40px 0px'});
  $$('.reveal').forEach(el=>io.observe(el));
}
function route(){
  state.cleanups.forEach(f=>f()); state.cleanups=[]; closeLayer(); document.body.style.overflow='';
  const raw = location.hash.replace(/^#/,'') || '/';
  const [path, query] = raw.split('?'); const qs = new URLSearchParams(query||'');
  const parts = path.split('/').filter(Boolean); const name = parts[0]||'home';
  const app = $('#app'); let html='';
  if(name==='search') html = searchPage(qs);
  else if(name==='property') html = detail(parts[1]);
  else if(name==='owners') html = owners();
  else if(name==='list') html = listPage();
  else if(name==='news') html = parts[1] ? newsArticle(parts[1]) : newsPage(qs);
  else html = home();
  app.innerHTML = html; state.routeName=name; renderNav(name);
  const sec = qs.get('s');
  if(sec && $('#'+sec)) requestAnimationFrame(()=>{ $('#'+sec).scrollIntoView({behavior:'auto'}); });
  else window.scrollTo(0,0);
  observe(); mount(name);
  document.title = ({search:'Search properties',property:'Property',owners:'AI agent for owners',list:'List your property',news:'Property news'}[name]||'Oman\'s AI property platform') + ' | Mumtalikati';
}
function mount(name){
  $$('[data-console]').forEach(c=>runConsole(c));
  if(name==='home'){
    let k=0; const inp=$('#aiq'); every(()=>{ if(inp && document.activeElement!==inp && !inp.value){ k=(k+1)%HINTS.length; inp.setAttribute('placeholder',HINTS[k]); } },3200);
  }
  if(name==='search') renderResults();
  if(name==='owners'){
    state.rules={repair:50,rent:390,relist:60,lease:true}; renderEvents();
    state.calc={total:20,rent:300,hours:6}; renderCalc();
    state.step=0; state.stepPaused=false;
    every(()=>{ if(state.stepPaused) return; setStep((state.step+1)%STEPS.length); },5000);
    typeFirst();
  }
  if(name==='list') listPreview();
}
function setStep(i){ state.step=i; $$('.step').forEach((b,j)=>{ b.classList.toggle('on',j===i); const pg=$('.prog',b); if(pg){ pg.style.animation='none'; void pg.offsetWidth; pg.style.animation=''; } }); const st=$('#stage'); if(st){ st.innerHTML=stageHtml(i); typeFirst(); } }
function typeFirst(){ const t=$('#stage .typed'); if(t) typeOut(t,t.dataset.type,22); }

/* ---------- EVENTS ---------- */
function toggleSave(id){
  if(!P.find(p=>p.id===id)) { toast('Preview only'); return; }
  const on = !state.saved.has(id); on?state.saved.add(id):state.saved.delete(id);
  $$(`[data-save="${id}"]`).forEach(b=>{ if(b.classList.contains('heart')){ b.classList.toggle('on',on); b.innerHTML = on?ic.heartF(18):ic.heart(18); b.setAttribute('aria-label',on?'Remove from saved':'Save property'); } else if(b.closest('.dgrid')){ b.innerHTML=(on?ic.heartF(16):ic.heart(16))+(on?' Saved':' Save'); } });
  const c=$('#savedCount'); if(c){ c.textContent=state.saved.size; c.classList.toggle('show',state.saved.size>0); }
  toast(on?'Saved. Find it under the heart at the top.':'Removed from saved', on?ic.heartF(16):ic.close(16));
  if($('.drawer')) savedDrawer();
}
function slide(media, dir){ const n=$$('.pc-track>div',media).length; let i=(+media.dataset.slide+dir+n)%n; media.dataset.slide=i; $('.pc-track',media).style.transform=`translateX(-${i*100}%)`; $$('.pc-dots i',media).forEach((d,j)=>d.classList.toggle('on',j===i)); }
function hl(id,on){ $$(`.pcard[data-id="${id}"]`).forEach(c=>c.classList.toggle('hl',on)); $$(`.pin[data-pin="${id}"]`).forEach(c=>c.classList.toggle('hl',on)); }
function chatSend(q){
  const chat=$('#chat'); const p=P.find(x=>x.id===+$('[data-agent]').dataset.agent); if(!chat||!q.trim()) return;
  chat.insertAdjacentHTML('beforeend',`<div class="msg u">${esc(q)}</div><div class="msg a" data-typing><span class="typing"><i></i><i></i><i></i></span></div>`); chat.scrollTop=chat.scrollHeight;
  later(()=>{ const t=$('[data-typing]',chat); if(t){ t.removeAttribute('data-typing'); t.textContent=answer(p,q); if(/[\u0600-\u06FF]/.test(t.textContent)) { t.setAttribute('dir','rtl'); t.classList.add('ar'); } chat.scrollTop=chat.scrollHeight; } },900+Math.random()*500);
}

document.addEventListener('click', e=>{
  const t = e.target;
  if(window._swiped && t.closest('.pc-media')){ window._swiped=false; return; }
  const save = t.closest('[data-save]'); if(save){ e.preventDefault(); e.stopPropagation(); toggleSave(+save.dataset.save); return; }
  const nav = t.closest('[data-nav]'); if(nav){ e.preventDefault(); e.stopPropagation(); slide(nav.closest('.pc-media'), +nav.dataset.nav); return; }
  const act = t.closest('[data-act]');
  if(act){
    const a = act.dataset.act;
    if(a==='close'){ if(act.tagName!=='A') e.preventDefault(); closeLayer(); return; }
    e.preventDefault();
    if(a==='theme'){ const r=document.documentElement; const dark = r.dataset.theme ? r.dataset.theme!=='dark' : !matchMedia('(prefers-color-scheme: dark)').matches; r.dataset.theme = dark?'dark':'light'; renderNav(state.routeName); toast(dark?'Dark mode on':'Light mode on', dark?ic.moon(16):ic.sun(16)); return; }
    if(a==='upload') return toast('Photo upload opens here in the live site.', ic.plus(16));
    if(a==='lang') return toast('The Arabic, right-to-left version is the next step for this prototype.', '<span class="ar">ع</span>');
    if(a==='saved') return savedDrawer();
    if(a==='menu') return mobileMenu();
    if(a==='store') return toast('App store links open here in the live site.');
    if(a==='wa') return toast('This opens WhatsApp in the live site.', ic.wa(16));
    if(a==='call') return toast('This starts a phone call in the live site.', ic.phone(16));
    if(a==='alert') return toast('Alert set. The agent will message you when a match is listed.', ic.bolt(16));
    if(a==='clearai'){ return go('#/search?p='+state.purpose); }
    if(a==='cleararea'){ return go('#/search?p='+state.purpose); }
    if(a==='mapm'){ const mb=$('#mapbox'); mb.classList.toggle('show'); const on=mb.classList.contains('show'); act.innerHTML = on? ic.list(16)+' List' : ic.map(16)+' Map'; document.body.style.overflow = on?'hidden':''; return; }
    if(a==='toagent'){ const box=$('#agentBox'); const p=P.find(x=>x.id===+box.dataset.agent); box.innerHTML=agentPanel(p,act.dataset.to); box.scrollIntoView({behavior:'smooth',block:'start'}); return; }
    if(a==='onboard'){ state.onb=null; return onboard(0); }
    if(a==='bookview'){ const d=$('.day.on'), s=$('.slot.on'); const box=$('[data-view]'); box.innerHTML=`<div class="success"><div class="check-anim">${ic.check(28)}</div><b style="font-size:18px">Viewing booked</b><span class="muted" style="font-size:14.5px">${$('span',d).textContent} ${$('b',d).textContent}, ${s.textContent}. The watchman will meet you at the entrance, and you'll get a WhatsApp reminder an hour before.</span></div>`; return; }
    if(a==='sendoffer'){
      const p=P.find(x=>x.id===+$('[data-agent]').dataset.agent); const v=+$('[data-range="offer"]').value; const res=$('#offerRes');
      res.innerHTML=`<div class="msg a" style="margin-top:14px;max-width:100%"><span class="typing"><i></i><i></i><i></i></span></div>`;
      later(()=>{ let m; const r=v/p.price; const unit=p.purpose==='sale'?1000:5; const counter=Math.round(p.price*.975/unit)*unit;
        if(r>=.975) m=`Good news: OMR ${fmt(v)} is inside the owner's range. I've reserved it for you for 24 hours and will send the ${p.purpose==='sale'?'sale agreement':'lease'} for the owner's final approval.`;
        else if(r>=.88) m=`Thanks. The owner can do OMR ${fmt(counter)}${p.purpose==='sale'?'':' with '+p.cheques+' cheques'}. Shall I hold it for you at that price?<div style="display:flex;gap:8px;margin-top:10px"><button class="btn btn-primary btn-sm" data-act="holdit">Yes, hold it</button></div>`;
        else m=`That's below what the owner can accept. Similar ${typeName(p.type).toLowerCase()}s nearby go for close to the asking price. Try a little higher?`;
        res.innerHTML=`<div class="msg a" style="margin-top:14px;max-width:100%">${m}</div>`; },1100);
      return;
    }
    if(a==='holdit'){ $('#offerRes').innerHTML=`<div class="success"><div class="check-anim">${ic.check(28)}</div><b>It's held for you for 24 hours</b><span class="muted" style="font-size:14px">The owner approves the final lease. We'll WhatsApp you the next steps.</span></div>`; return; }
    if(a==='aiwrite'){
      const L=state.lst; const kind=typeName(L.type).toLowerCase(); const f=L.feat;
      const title = (L.type==='shop'||L.type==='office') ? `${f.includes('Parking')?'Well-located':'Prime'} ${kind} in ${L.area}` : `${f.includes('Sea view')?'Sea-view':f.includes('Furnished')?'Furnished':'Bright'} ${L.beds}-bed ${kind} in ${L.area}`;
      const desc = (L.type==='shop'||L.type==='office') ? `A practical ${kind} in ${L.area} with good visibility and easy access.${f.length?' Includes '+f.join(', ').toLowerCase()+'.':''} Available now at OMR ${fmt(+L.rent)} a month, payable by post-dated cheques.` : `A ${f.includes('Furnished')?'fully furnished':'well-kept'} ${L.beds}-bedroom ${kind} in ${L.area}${f.includes('Sea view')?' with views of the sea':''}.${f.length?' Comes with '+f.join(', ').toLowerCase()+'.':''} Close to shops, mosques and schools. OMR ${fmt(+L.rent)} a month on a 12-month lease, payable by post-dated cheques.`;
      const arT = (L.type==='shop'||L.type==='office') ? `${L.type==='shop'?'محل':'مكتب'} للإيجار في ${arArea(L.area)}` : `${L.type==='villa'?'فيلا':L.type==='townhouse'?'تاون هاوس':'شقة'} ${L.beds} غرف نوم للإيجار في ${arArea(L.area)}`;
      $('#aiOut').innerHTML = `<div class="ai-out"><span class="pill pill-ai"><span class="dot"></span>Written by AI · edit anything</span><h3 style="margin:14px 0 6px;font-size:22px;letter-spacing:-.02em" id="aiT"></h3><p class="ar" dir="rtl" style="margin:0 0 10px;color:var(--red);font-weight:500" id="aiA"></p><p class="muted" style="margin:0" id="aiD"></p><div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px"><button class="btn btn-primary" data-act="publish">Publish free ${ic.arrow(16)}</button><button class="btn btn-ghost" data-act="aiwrite">${ic.spark(16)} Rewrite</button></div></div>`;
      portalUI();
      typeOut($('#aiT'),title,24,()=>{ $('#aiA').textContent=arT; typeOut($('#aiD'),desc,12); });
      L.title=title; listPreview(); return;
    }
    if(a==='publish' && state.lst && state.lst.portals.length){ const sel=PORTALS.filter(p=>state.lst.portals.includes(p[0])).map(p=>p[1]); openLayer(`<div class="overlay" data-close-bg><div class="modal" role="dialog" aria-modal="true" aria-label="Premium needed"><button class="icon-btn x" data-act="close" aria-label="Close">${ic.close()}</button><span class="tag-prem">${ic.bolt(11)}PREMIUM</span><h2 style="margin:14px 0 6px;font-size:28px;letter-spacing:-.03em;line-height:1.1">Post to ${sel.length+1} portals with one click</h2><p class="muted" style="margin:0 0 16px">Your listing goes on Mumtalikati for free. To post it on ${sel.length>1?sel.slice(0,-1).join(', ')+' and '+sel[sel.length-1]:sel[0]} as well, subscribe to Premium.</p><ul class="ticks" style="margin-bottom:20px"><li>${ic.check(16)}One form, posted to every portal you pick</li><li>${ic.check(16)}Change the price once and every portal updates</li><li>${ic.check(16)}Taken down everywhere as soon as it's let</li><li>${ic.check(16)}All enquiries land in one Mumtalikati inbox</li></ul><div style="display:flex;gap:10px;flex-wrap:wrap"><a class="btn btn-primary" href="#/owners?s=pricing" data-act="close">Subscribe to Premium ${ic.arrow(16)}</a><button class="btn btn-ghost" data-act="publishfree">Publish on Mumtalikati only</button></div><p class="muted" style="font-size:12.5px;margin:14px 0 0">Prototype: nothing was published or charged.</p></div></div>`); return; }
    if(a==='publishfree'){ closeLayer(); state.lst.portals=[]; $$('[data-portal]').forEach(b=>{b.classList.remove('on');b.setAttribute('aria-pressed','false');}); portalUI(); }
    if(a==='publish'||a==='publishfree'){ openLayer(`<div class="overlay" data-close-bg><div class="modal" role="dialog" aria-modal="true" aria-label="Published"><div class="success"><div class="check-anim">${ic.check(30)}</div><h2 style="margin:6px 0 0;font-size:28px;letter-spacing:-.03em">Your listing is live</h2><p class="muted" style="margin:0">Want the AI agent to answer enquiries and book viewings for it?</p><div style="display:flex;gap:10px;flex-wrap:wrap;justify-content:center;margin-top:8px"><a class="btn btn-primary" href="#/owners" data-act="close">Turn on the AI agent</a><button class="btn btn-ghost" data-act="close">Not now</button></div><p class="muted" style="font-size:12.5px">Prototype: nothing was published.</p></div></div></div>`); return; }
    return;
  }
  if(t.closest('[data-close-bg]') && (t.matches('[data-close-bg]'))) { closeLayer(); return; }
  const hint = t.closest('[data-hint]'); if(hint){ const i=$('#aiq'); i.value=hint.dataset.hint; $('[data-form="ai"]').requestSubmit(); return; }
  const pur = t.closest('[data-purpose]'); if(pur){ state.purpose=pur.dataset.purpose; $$('[data-purpose]').forEach(b=>b.classList.toggle('on',b===pur)); return; }
  const sp = t.closest('[data-spurpose]'); if(sp){ return go('#/search?p='+sp.dataset.spurpose); }
  const hc = t.closest('[data-homecat]'); if(hc){ $$('[data-homecat]').forEach(b=>b.classList.toggle('on',b===hc)); const k=hc.dataset.homecat; const list=P.filter(p=>k==='all'?p.purpose==='rent':p.type===k); $('#homeRail').innerHTML = list.length? list.map((p,i)=>card(p,{style:`animation:lineIn .6s var(--ease) ${i*.06}s both`})).join('') : `<div class="empty">No ${hc.textContent.trim().toLowerCase()} right now.</div>`; return; }
  const rl = t.closest('[data-rail]'); if(rl){ $('#homeRail').scrollBy({left:+rl.dataset.rail*340,behavior:'smooth'}); return; }
  const tg = t.closest('[data-tog]'); if(tg){ const k=tg.dataset.tog; state.filters[k]=!state.filters[k]; tg.classList.toggle('on',state.filters[k]); renderResults(); return; }
  const pin = t.closest('[data-pin]'); if(pin){ const c=$(`#results .pcard[data-id="${pin.dataset.pin}"]`); if(c){ $('#mapbox').classList.remove('show'); document.body.style.overflow=''; const fab=$('.map-fab'); if(fab) fab.innerHTML=ic.map(16)+' Map'; c.scrollIntoView({behavior:'smooth',block:'center'}); hl(pin.dataset.pin,true); setTimeout(()=>hl(pin.dataset.pin,false),1600);} return; }
  const tab = t.closest('[data-tab]'); if(tab){ const box=$('[data-agent]'); const p=P.find(x=>x.id===+box.dataset.agent); box.innerHTML=agentPanel(p,tab.dataset.tab); return; }
  const q = t.closest('[data-q]'); if(q){ chatSend(q.dataset.q); return; }
  const day = t.closest('[data-day]'); if(day){ $$('[data-day]').forEach(b=>b.classList.toggle('on',b===day)); return; }
  const sl = t.closest('[data-slot]'); if(sl){ $$('[data-slot]').forEach(b=>b.classList.toggle('on',b===sl)); return; }
  const lb = t.closest('[data-lb]'); if(lb){ lightbox(+lb.dataset.lb); return; }
  const lg = t.closest('[data-lbgo]'); if(lg){ lightbox(state.lb + +lg.dataset.lbgo); return; }
  const st = t.closest('[data-step]'); if(st){ setStep(+st.dataset.step); state.stepPaused=true; later(()=>state.stepPaused=false,12000); return; }
  const qa = t.closest('[data-qa]'); if(qa){ const w=qa.parentElement; const open=!w.classList.contains('open'); w.classList.toggle('open',open); qa.setAttribute('aria-expanded',open); return; }
  const bill = t.closest('[data-bill]'); if(bill){ $$('[data-bill]').forEach(b=>b.classList.toggle('on',b===bill)); const y=bill.dataset.bill==='y'; $$('[data-price]').forEach(s=>s.textContent=(+s.dataset.price*(y?.81:1)).toFixed(3)); return; }
  const rt = t.closest('[data-rule-tog]'); if(rt){ state.rules.lease=!state.rules.lease; rt.classList.toggle('on',state.rules.lease); renderEvents(); return; }
  const dec = t.closest('[data-decide]'); if(dec){ const box=dec.closest('[data-dec]'); const c=dec.dataset.decide==='counter'; box.innerHTML=`<span style="font-size:14px;color:#FFB27A;font-weight:600">${ic.check(15)} ${c?'Counter of OMR 395 sent. I\'ll update you when Ahmed replies.':'Accepted. The lease is ready for your approval.'}</span>`; return; }
  const ow = t.closest('[data-onb-who]'); if(ow){ state.onb.who=ow.dataset.onbWho; return onboard(1); }
  const ou = t.closest('[data-onb-units]'); if(ou){ state.onb.units=ou.dataset.onbUnits; return onboard(2); }
  const lt = t.closest('[data-lt]'); if(lt){ $$('[data-lt]').forEach(b=>b.classList.toggle('on',b===lt)); state.lst.type=lt.dataset.lt; state.lst.title=null; listPreview(); return; }
  const lb2 = t.closest('[data-lb2]'); if(lb2){ $$('[data-lb2]').forEach(b=>b.classList.toggle('on',b===lb2)); state.lst.beds=+lb2.dataset.lb2; state.lst.title=null; listPreview(); return; }
  const pt = t.closest('[data-portal]'); if(pt){ const on=!pt.classList.contains('on'); pt.classList.toggle('on',on); pt.setAttribute('aria-pressed',on); const L=state.lst; const k=pt.dataset.portal; L.portals = on ? L.portals.concat(k) : L.portals.filter(x=>x!==k); portalUI(); return; }
  const ft = t.closest('[data-feat]'); if(ft){ ft.classList.toggle('on'); const f=ft.dataset.feat; const L=state.lst; L.feat = ft.classList.contains('on') ? L.feat.concat(f) : L.feat.filter(x=>x!==f); return; }
  const open = t.closest('[data-open]'); if(open && open.dataset.open){ go('#/property/'+open.dataset.open); return; }
});
function arArea(a){ return ({'Al Khuwair':'الخوير','Azaiba':'العذيبة','Shatti Al Qurum':'شاطئ القرم','Al Mouj':'الموج','Al Mawaleh':'الموالح','Al Hail':'الحيل','Ghubra':'الغبرة','Ruwi':'روي','Muttrah':'مطرح'})[a]||a; }
document.addEventListener('submit', e=>{
  const f = e.target.closest('[data-form]'); if(!f) return; e.preventDefault();
  const k=f.dataset.form;
  if(k==='ai'||k==='aimini'){ const q=$('input',f).value.trim() || ($('#aiq')&&$('#aiq').getAttribute('placeholder')) || ''; go('#/search?p='+state.purpose+'&q='+encodeURIComponent(q)); }
  if(k==='chat'){ const i=$('input',f); chatSend(i.value); i.value=''; }
  if(k==='onb'){ state.onb.name=$('#onn').value.trim(); state.onb.wa=$('#onw').value.trim(); onboard(3); }
});
document.addEventListener('change', e=>{
  const s=e.target.closest('[data-f]'); if(s){ const k=s.dataset.f; state.filters[k] = k==='type'||k==='sort' ? s.value : (+s.value||null); if(k==='beds') state.filters.beds=+s.value||0; renderResults(); }
  const lf=e.target.closest('[data-lf]'); if(lf){ state.lst[lf.dataset.lf]=lf.value; state.lst.title=null; listPreview(); }
});
document.addEventListener('input', e=>{
  const r=e.target;
  if(r.matches('[data-range="offer"]')){ $('#offerVal').textContent=fmt(+r.value); $('#offerRes').innerHTML=''; }
  if(r.matches('[data-rule]')){ const k=r.dataset.rule; state.rules[k]=+r.value; $('#vRepair').textContent='OMR '+state.rules.repair; $('#vRent').textContent='OMR '+state.rules.rent; $('#vRelist').textContent=state.rules.relist+' days'; renderEvents(); }
  if(r.matches('[data-calc]')){ state.calc[r.dataset.calc]=+r.value; renderCalc(); }
  if(r.matches('[data-lf="rent"]')){ state.lst.rent=r.value; listPreview(); }
});
document.addEventListener('mouseover', e=>{ const c=e.target.closest('#results .pcard'); if(c) hl(c.dataset.id,true); const p=e.target.closest('.pin'); if(p) hl(p.dataset.pin,true); });
document.addEventListener('mouseout', e=>{ const c=e.target.closest('#results .pcard'); if(c && !c.contains(e.relatedTarget)) hl(c.dataset.id,false); const p=e.target.closest('.pin'); if(p) hl(p.dataset.pin,false); });
document.addEventListener('mousemove', e=>{ const b=e.target.closest('.bcard, .ncard'); if(b){ const r=b.getBoundingClientRect(); b.style.setProperty('--mx',(e.clientX-r.left)+'px'); b.style.setProperty('--my',(e.clientY-r.top)+'px'); } });
document.addEventListener('keydown', e=>{
  if(e.key==='Escape' && $('#layer').innerHTML) closeLayer();
  if($('.lightbox')){ if(e.key==='ArrowRight') lightbox(state.lb+1); if(e.key==='ArrowLeft') lightbox(state.lb-1); }
  if(e.key==='Enter'){ const c=e.target.closest&&e.target.closest('.pcard[data-open], .g[data-lb]'); if(c && e.target===c) c.click(); }
});
addEventListener('scroll', ()=>{ $('#nav').classList.toggle('scrolled', scrollY>20); }, {passive:true});
addEventListener('resize', ()=>{ const mb=$('#mapBtn'); if(mb) mb.style.display = innerWidth<=1080 ? 'inline-flex':'none'; });
let sx=null, sy=null;
document.addEventListener('touchstart', e=>{ const m=e.target.closest('.pc-media'); if(!m) return; sx=e.touches[0].clientX; sy=e.touches[0].clientY; },{passive:true});
document.addEventListener('touchend', e=>{ const m=e.target.closest('.pc-media'); if(!m||sx===null) return; const dx=e.changedTouches[0].clientX-sx, dy=e.changedTouches[0].clientY-sy; if(Math.abs(dx)>40 && Math.abs(dx)>Math.abs(dy)*1.3 && $$('.pc-track>div',m).length>1){ slide(m, dx<0?1:-1); window._swiped=true; setTimeout(()=>window._swiped=false,400); } sx=null; },{passive:true});
addEventListener('hashchange', route);
renderFooter(); route();
})();
