window.MPH={
 "townhouse": {
  "src": "images/townhouse.webp",
  "alt": "Modern 3-bed townhouse with garden and balcony"
 },
 "modern_villa": {
  "src": "images/modern_villa.webp",
  "alt": "Modern villa with glass balconies and lawn"
 },
 "omani_villa": {
  "src": "images/omani_villa.webp",
  "alt": "Single-storey Omani-style villa with columned entrance"
 },
 "khuwair": {
  "src": "images/khuwair.webp",
  "alt": "New apartment buildings with mountain views"
 },
 "msq_villa": {
  "src": "images/msq_villa.webp",
  "alt": "Classic stone-fronted villa on a quiet street"
 },
 "pool_villa": {
  "src": "images/pool_villa.webp",
  "alt": "Villa with private pool facing the water and mountains"
 },
 "shatti": {
  "src": "images/shatti.webp",
  "alt": "White apartment building on a main road in Shatti Al Qurum"
 }
};
